/*
 *  Copyright (c) 1992-2014 Matisse Software Inc. All Rights Reserved.
 *
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 *
 */

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.math.BigDecimal;
import java.util.Iterator;

import com.matisse.MtDatabase;
import com.matisse.MtException;
import com.matisse.MtObjectIterator;
import com.matisse.MtPropertyIterator;
import com.matisse.MtCoreObjectFactory;

import com.matisse.reflect.MtObject;
import com.matisse.reflect.MtClass;
import com.matisse.reflect.MtNamespace;
import com.matisse.reflect.MtAttribute;
import com.matisse.reflect.MtRelationship;
import com.matisse.reflect.MtIndex;
import com.matisse.reflect.MtEntryPointDictionary;
import com.matisse.reflect.MtType;


/**
 * This class shows how to create/list/delete objects with Matisse 
 * using Matisse reflection API.
 *
 */
public class ReflectionExample {

  public static void main(String[] args) {
    if (args.length < 2) {
      System.out.println("Need to specify <HOST> <DATABASE>");
      System.exit(-1);
	}

    String hostname = args[0];
    String dbname = args[1];

    // Create a few Person objects
    createObjects(hostname, dbname);

    // List the created objects
    listObjects(hostname, dbname);

    // Lookup objects from an Index
    indexLookup(hostname, dbname);

    // Lookup objects from an Entry Point Dictionary
    entryPointLookup(hostname, dbname);

    // List all object properties
    listObjectProperties(hostname, dbname);

    // Add a class to an existing schema
    addClass(hostname, dbname);

    // Delete the created objects
    deleteObjects(hostname, dbname);

    // Remove the newly created class
    removeClass(hostname, dbname);

  }

  /**
   * Create a few objects
   */ 
  public static void createObjects(String hostname, String dbname)
    {
      System.out.println("=========== CreateObjects ==========\n");

      try {
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtCoreObjectFactory());

	    db.open();
	    db.startTransaction();

	    System.out.println("Creating one Person...");
	    // Create a Person object
	    MtClass pClass = MtClass.get(db, "examples.java_examples.reflection.Person");
	    MtAttribute fnAtt = MtAttribute.get(db, "FirstName", pClass);
	    MtAttribute lnAtt = MtAttribute.get(db, "LastName", pClass);
	    MtAttribute cgAtt = MtAttribute.get(db, "collegeGrad", pClass);
	    MtObject p = new MtObject(pClass);
	    p.setString(fnAtt, "John");
	    p.setString(lnAtt, "Smith");
	    p.setBoolean(cgAtt, false);

	    System.out.println("Creating one Employee...");
	    // Create a Employee object
	    MtClass eClass = MtClass.get(db, "examples.java_examples.reflection.Employee");
	    MtAttribute hdAtt = MtAttribute.get(db, "hireDate", eClass);
	    MtAttribute slAtt = MtAttribute.get(db, "salary", eClass);
	    MtObject e = new MtObject(eClass);
	    e.setString(fnAtt, "James");
	    e.setString(lnAtt, "Roberts");
	    e.setDate(hdAtt, new GregorianCalendar(2009, Calendar.JANUARY, 6));
	    e.setNumeric(slAtt, new BigDecimal("5123.25"));
	    e.setBoolean(cgAtt, true);

	    System.out.println("Creating one Manager...");
	    // Create a Manager object
	    MtClass mClass = MtClass.get(db, "examples.java_examples.reflection.Manager");
	    MtRelationship tmRshp = MtRelationship.get(db, "team", mClass);
	    MtObject m = new MtObject(mClass);
	    m.setString(fnAtt, "Andy");
	    m.setString(lnAtt, "Brown");
	    m.setDate(hdAtt, new GregorianCalendar(2008, Calendar.NOVEMBER, 8));
	    m.setNumeric(slAtt, new BigDecimal("7421.25"));
	    m.setSuccessors(tmRshp, new MtObject[] {m, e});
	    m.setBoolean(cgAtt, true);

	    db.commit();
	    db.close();
	    System.out.println("Done.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
        mte.printStackTrace();
      }
    }


  /**
   * List objects
   */ 
  public static void listObjects(String hostname, String dbname)
    {
      System.out.println("=========== ListObjects ==========\n");

      try {
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtCoreObjectFactory());

	    db.open();
	    db.startVersionAccess();

	    MtClass pClass = MtClass.get(db, "examples.java_examples.reflection.Person");
	    MtAttribute fnAtt = MtAttribute.get(db, "FirstName", pClass);
	    MtAttribute lnAtt = MtAttribute.get(db, "LastName", pClass);
	    MtAttribute cgAtt = MtAttribute.get(db, "collegeGrad", pClass);

	    // List all objects
	    System.out.println("\n" + pClass.getInstanceNumber() +
                           " Person(s) in the database.");

	    // Retrieve the object from the previous transaction
	    MtObjectIterator<MtObject> iter = pClass.<MtObject>instanceIterator();
	    while (iter.hasNext()) {
          MtObject p = iter.next();

          System.out.println("- " + p.getMtClass().getMtName() + " #" + p.getMtOid());

          System.out.println("  " + p.getString(fnAtt) + " " +
                             p.getString(lnAtt) + 
                             " collegeGrad=" + p.getBoolean(cgAtt));
	    }
	    iter.close();

	    db.endVersionAccess();
	    db.close();
	    System.out.println("Done.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
        mte.printStackTrace();
      }
    }

  /**
   * Lookup objects from an Index
   */ 
  public static void indexLookup(String hostname, String dbname)
    {
      System.out.println("=========== indexLookup ==========\n");

      String firstName = "Andy";
      String lastName = "Brown";

      try {
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtCoreObjectFactory());

	    db.open();
	    db.startVersionAccess();

	    MtClass pClass = MtClass.get(db, "examples.java_examples.reflection.Person");
	    MtAttribute fnAtt = MtAttribute.get(db, "FirstName", pClass);
	    MtAttribute lnAtt = MtAttribute.get(db, "LastName", pClass);

	    // Get the Index Descriptor object
	    MtIndex iClass = MtIndex.get(db, "examples.java_examples.reflection.personName");

	    // Get the number of entries in the index
	    long count = iClass.getIndexEntriesNumber();
	    System.out.println(count + " entries in the index.");

        System.out.println("Looking for: " + firstName + " " + lastName);

	    // lookup for the number of objects matching the key
	    Object[] key = new Object[] { lastName, firstName } ;
	    count = iClass.getObjectNumber(key, null);
	    System.out.println(count + " matching objects to be retrieved.");

	    if (count > 1) {
          // More than one matching object
          // Retrieve them with an iterator
          MtObjectIterator<MtObject> iter = iClass.iterator(key);
          while (iter.hasNext()) {
		    MtObject p = iter.next();
		    System.out.println("  found " + p.getString(fnAtt) + " " +
                               p.getString(lnAtt));
          }
	    } else {
          // At most 1 object
          // Retrieve the matching object with the lookup method
          MtObject p = iClass.lookup(key);
          if (p != null) {
		    System.out.println("  found " + p.getString(fnAtt) + " " +
                               p.getString(lnAtt));
          } else {
		    System.out.println("  Nobody found");
          }
	    }

	    db.endVersionAccess();
	    db.close();
	    System.out.println("Done.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
        mte.printStackTrace();
      }
    }

  /**
   * Lookup objects from an Entry Point Dictionary
   */ 
  public static void entryPointLookup(String hostname, String dbname)
    {
      System.out.println("=========== entryPointLookup ==========\n");

      String collegeGrad = "true";

      try {
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtCoreObjectFactory());

	    db.open();
	    db.startVersionAccess();

	    MtClass pClass = MtClass.get(db, "examples.java_examples.reflection.Person");
	    MtAttribute fnAtt = MtAttribute.get(db, "FirstName", pClass);
	    MtAttribute lnAtt = MtAttribute.get(db, "LastName", pClass);
	    MtAttribute cgAtt = MtAttribute.get(db, "collegeGrad", pClass);

	    // Get the Index Descriptor object
	    MtEntryPointDictionary epClass = MtEntryPointDictionary.get(db, "examples.java_examples.reflection.collegeGradDict");

        System.out.println("Looking for Persons with CollegeGrad=" + collegeGrad);

	    // lookup for the number of objects matching the key
	    long count = epClass.getObjectNumber(collegeGrad, null);
	    System.out.println(count + " matching objects to be retrieved.");

	    if (count > 1) {
          // More than one matching object
          // Retrieve them with an iterator
          MtObjectIterator<MtObject> iter = epClass.iterator(collegeGrad);
          while (iter.hasNext()) {
		    MtObject p = iter.next();
		    System.out.println("  found " + p.getString(fnAtt) + " " +
                               p.getString(lnAtt) + 
                               " collegeGrad=" + p.getBoolean(cgAtt));
          }
	    } else {
          // At most 1 object
          // Retrieve the matching object with the lookup method
          MtObject p = epClass.lookup(collegeGrad);
          if (p != null) {
		    System.out.println("  found " + p.getString(fnAtt) + " " +
                               p.getString(lnAtt) + 
                               " collegeGrad=" + p.getBoolean(cgAtt));
          } else {
		    System.out.println("  Nobody found");
          }
	    }

	    db.endVersionAccess();
	    db.close();
	    System.out.println("Done.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
        mte.printStackTrace();
      }
    }

  /**
   * List objects
   */ 
  public static void listObjectProperties(String hostname, String dbname)
    {
      System.out.println("=========== listObjectProperties ==========\n");

      try {
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtCoreObjectFactory());

	    db.open();
	    db.startVersionAccess();

	    MtClass pClass = MtClass.get(db, "examples.java_examples.reflection.Person");

	    // List all objects
	    System.out.println("\n" + pClass.getInstanceNumber() +
                           " Person(s) in the database.");

	    // Retrieve the object from the previous transaction
	    MtObjectIterator<MtObject> iter = pClass.instanceIterator();
	    while (iter.hasNext()) {
          MtObject p = iter.next();

          System.out.println("- " + p.getMtClass().getMtName() + " #" + p.getMtOid());

          System.out.println(" Attributes:");
          MtPropertyIterator<MtAttribute> propIter = p.attributesIterator();
          MtAttribute a;
          String propName;
          int propType, valType;
          String fmtVal;
          while (propIter.hasNext()) {
		    a = propIter.next();
		    propName = a.getMtName();
		    propType = a.getMtType();
		    valType = p.getType(a);
		    fmtVal = null;
		    switch (valType) {
		    case MtType.DATE:
              fmtVal = String.format("%1$tY-%1$tm-%1$td", p.getDate(a));
              break;
		    case MtType.NUMERIC:
              fmtVal = p.getNumeric(a).toString();
              break;
		    case MtType.NULL:
              fmtVal = null;
              break;
		    default:
              fmtVal = p.getValue(a).toString();
		    }
		    System.out.println("\t" + propName + 
                               " (" + MtType.toString(propType) +
                               "):\t" + fmtVal + " (" + MtType.toString(valType) + ")");
          }
          propIter.close();

          System.out.println(" Relationships:");
          MtPropertyIterator<MtRelationship> rshpIter = p.relationshipsIterator();
          MtRelationship r;
          while (rshpIter.hasNext()) {
		    r = rshpIter.next();
		    System.out.println("\t" + r.getMtName() + 
                               ":\t" + p.getSuccessorSize(r) + " element(s)");
          }
          rshpIter.close();

          System.out.println(" Inverse Relationships:");
          rshpIter = p.inverseRelationshipsIterator();
          while (rshpIter.hasNext()) {
		    r = rshpIter.next();
		    System.out.println("\t" + r.getMtName() + 
                               ":\t" + p.getSuccessorSize(r) + " element(s)");
          }
          rshpIter.close();
	    }
	    iter.close();

	    db.endVersionAccess();
	    db.close();
	    System.out.println("Done.");

      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
        mte.printStackTrace();
      }
    }

  /**
   * Add a Class to an existing schema
   */ 
  public static void addClass(String hostname, String dbname)
    {
      System.out.println("=========== addClass ==========\n");

      try {
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtCoreObjectFactory());

	    // open connection in DDL mode
	    db.setOption(MtDatabase.DATA_ACCESS_MODE, MtDatabase.DATA_DEFINITION);
	    db.open();

	    db.startTransaction();

	    MtClass pClass = MtClass.get(db, "examples.java_examples.reflection.Person");

	    System.out.println("Creating 'PostalAddress' class and linking it to 'Person'...");
	    System.out.println("in 'Person's namespace: " + pClass.getMtNamespaceClassOf().getMtFullName());
	    // Create a new Class

	    // Create attributes
	    MtAttribute cAtt = new MtAttribute(db, "City", MtType.STRING);
	    MtAttribute pcAtt = new MtAttribute(db, "PostalCode", MtType.STRING);
        // nullable
        pcAtt.setMtNullable(true);
        // max size of 5 characters
        pcAtt.getMtAttributeType().setMtMaxSize(5);

        // another way to get the namespace
        MtNamespace ns = MtNamespace.get(db, "examples.java_examples.reflection");
        if (ns == null) {
          // and to create a namespace path
          ns  =  MtNamespace.create(db, "examples.java_examples.reflection");
        } 
        
	    MtClass paClass = new MtClass(db, "PostalAddress", ns, new MtAttribute[] { cAtt, pcAtt }, null);

	    MtRelationship adRshp = new MtRelationship(db, "Address", paClass, new int[]{0, 1} );
	    pClass.addMtRelationship(adRshp);

	    System.out.println("- " + paClass.getMtClass().getMtFullName() +  
                           " " + paClass.getMtFullName() + 
                           " (#" + paClass.getMtOid() + ") created");
	    System.out.println("Done.");

	    db.commit();
	    db.close();
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
        mte.printStackTrace();
      }
    }

  /**
   * Delete objects
   */ 
  public static void deleteObjects(String hostname, String dbname)
    {
      System.out.println("=========== DeleteObjects ==========\n");

      try {
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtCoreObjectFactory());

	    db.open();
	    db.startTransaction();

	    MtClass pClass = MtClass.get(db, "examples.java_examples.reflection.Person");

	    // List all objects
	    System.out.println("\n" + pClass.getInstanceNumber() +
                           " Person(s) in the database.");
	    System.out.println("Deleting...");

	    // Retrieve the object from the previous transaction
	    MtObjectIterator<MtObject> iter = pClass.instanceIterator();
	    while (iter.hasNext()) {
          MtObject p = iter.next();

          p.deepRemove();
	    }
	    iter.close();
	    System.out.println("Done.");
	    System.out.println("\n" + pClass.getInstanceNumber() +
                           " Person(s) in the database.");
	    db.commit();
	    db.close();
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
        mte.printStackTrace();
      }
    }
  /**
   * Remove the newly created class
   */ 
  public static void removeClass(String hostname, String dbname)
    {
      System.out.println("=========== removeClass ==========\n");

      try {
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtCoreObjectFactory());

	    // open connection in DDL mode
	    db.setOption(MtDatabase.DATA_ACCESS_MODE, MtDatabase.DATA_DEFINITION);
	    db.open();

	    db.startTransaction();
	    MtClass paClass = MtClass.get(db, "examples.java_examples.reflection.PostalAddress");
        if (paClass != null) {
          System.out.println("Removing " + paClass.getMtClass().getMtName() +  
                             " " + paClass.getMtName() + 
                             " (#" + paClass.getMtOid() + ")...");

          paClass.deepRemove();
        }
	    db.commit();
	    db.close();
	    System.out.println("Done.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
        mte.printStackTrace();
      }
    }



}
