/*
 *  MethodCallExample.java
 *
 *  Copyright (c) 2002-2012 Matisse Software, Inc. All Rights Reserved.
 *
 * 
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 */

import java.util.Iterator;

import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.CallableStatement;

import com.matisse.MtDatabase;

import com.matisse.reflect.MtType;
import com.matisse.reflect.MtObject;

import com.matisse.sql.MtConnection;
import com.matisse.sql.MtResultSet;
import com.matisse.sql.MtStatement;
import com.matisse.sql.MtCallableStatement;

import examples.java_examples.sql_methods.Member;


/**
 * This examples illustrates Matisse Event Notification mechansim.
 * The sample application is divided in 2 sections. The first section 
 * is event selection and notification. The second section is event registration 
 * and event handling.
 */
/*
 * Sample application which illustrates that Matisse SQL Method calls
 * from a Java stub class.
 *
 * The application creates a data-set and executes both instance and static   
 * methods.
 */
public final class MethodCallExample {
    
  public static void main(String[] args) 	
	throws java.sql.SQLException
    {

      if (args.length < 2) {
	    System.out.println("Usage:");
	    System.out.println("  MethodCallExample <HOST> <DATABASE> ");
	    System.exit(1);
      }

      String hostname = args[0];
      String dbname = args[1];

      // Clear all data
      cleanupData(hostname, dbname);

      // create data
      createData(hostname, dbname);

      // Execute instance Method Call
      instanceMethodCall(hostname, dbname);

      // Execute static Method Call
      staticMethodCall(hostname, dbname);
    }


  /** Execute create data */
  public static void cleanupData(String hostname, String dbname)
	throws java.sql.SQLException
    {
      System.out.println("\n\n=========== cleanup Data ==========\n");

      MtDatabase dbcon = new MtDatabase(hostname, dbname);

      // Open the connection to the database
      dbcon.open();
      dbcon.startTransaction();

      // Data clean up
      Iterator<Member> iter = Member.instanceIterator(dbcon);
      while (iter.hasNext()) {
	    Member x = iter.next();     
	    x.deepRemove();
      }

      dbcon.commit();

      // Close the database connection
      dbcon.close();

      System.out.println("Done.");
    }


  /** Execute create data */
  public static void createData(String hostname, String dbname)
	throws java.sql.SQLException
    {
      System.out.println("\n\n=========== Create Data ==========\n");

      MtDatabase dbcon = new MtDatabase(hostname, dbname);

      // Open the connection to the database
      dbcon.open();
      dbcon.startTransaction();

      // New Data set

      // 1 - John M Doe
      System.out.println("Member #1 - John M Doe");
      Member m = new Member(dbcon);
      m.setMemberId(1);
      m.setFirstName("John");
      m.setMiddleName("M");
      m.setLastName("Doe");

      // 2 - Jack Brown
      System.out.println("Member #2 - Jack Brown");
      m = new Member(dbcon);
      m.setMemberId(2);
      m.setFirstName("Jack");
      m.setLastName("Brown");

      // 3 - Bill E Johnson
      System.out.println("Member #3 - Bill E Johnson");
      m = new Member(dbcon);
      m.setMemberId(3);
      m.setFirstName("Bill");
      m.setMiddleName("E");
      m.setLastName("Johnson");

      dbcon.commit();

      // Close the database connection
      dbcon.close();

      System.out.println("Done.");
    }


  /** Execute instance Method Call */
  public static void instanceMethodCall(String hostname, String dbname)
	throws java.sql.SQLException
    {
      System.out.println("\n\n=========== instance Method Call ==========\n");

      MtDatabase dbcon = new MtDatabase(hostname, dbname);

      // Open the connection to the database
      dbcon.open();

      dbcon.startVersionAccess();

      int mid = 1;
      Member obj = Member.lookupMemberIdIdx(dbcon, mid);

      // "GetFullName" SQL Method call
      String res = obj.getFullName();
	
      System.out.println("Member #" + mid + " full name: " + res);

      dbcon.endVersionAccess();
      // Close the database connection
      dbcon.close();

      System.out.println("Done.");
    }

  /** Execute static Method Call */
  public static void staticMethodCall(String hostname, String dbname)
	throws java.sql.SQLException
    {
      System.out.println("\n\n=========== static Method Call ==========\n");

      MtDatabase dbcon = new MtDatabase(hostname, dbname);

      // Open the connection to the database
      dbcon.open();

      dbcon.startVersionAccess();

      int mid = 2;
      // "getPersonFullName" SQL Method call
      String res = Member.getPersonFullName(dbcon, mid);

      System.out.println("Member #" + mid + " full name: " + res);

      mid = 3;
      // "getPersonFullName" SQL Method call
      res = Member.getPersonFullName(dbcon, mid);

      System.out.println("Member #" + mid + " full name: " + res);

      dbcon.endVersionAccess();

      // Close the database connection
      dbcon.close();

      System.out.println("Done.");
    }

}
