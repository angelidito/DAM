/*
 *  Copyright (c) 1992-2014 Matisse Software Inc. All Rights Reserved.
 *
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 *
 */

import java.util.GregorianCalendar;

import com.matisse.MtDatabase;
import com.matisse.MtException;

import com.matisse.reflect.MtAttribute;

import examples.java_examples.revision.Chip1;
import examples.java_examples.revision.Chip2;
import examples.java_examples.revision.Motherboard;
import examples.java_examples.revision.Revisable;


/*
 * Sample application which illustrates that Matisse stores attributes
 * as Objects and an attributes value can be Null.
 *
 * The application checks for Null attributes and looks for other
 * revisions or branches (stored as successors to relationships) to find
 * instance where specified attribute is non-Null.
 */
public class Revision
{
  MtDatabase db;
    
  public Revision(String dbname) {
    db = new MtDatabase(dbname);
    db.open();
  }

  /**
   * main function (no argument checking !)
   * usage :
   *   Revision <db>[@host] dump baserev
   *   Revision <db>[@host] set baserev {Motherboard|Chip1|Chip2} Param<x> <val>
   */
  public static void main(String[] args) {
    if (args.length<2) {
      System.out.println("usage:");
      System.out.println("  Revision <db>[@host] dump <baserev>");
      System.out.println("  Revision <db>[@host] set <baserev> {Motherboard|Chip1|Chip2} param<x> <val>");
    }
        
    Revision main = new Revision(args[0]);
    String action = args[1];

    if (action.equals("dump")) {
      main.dump(args[2]);
    } else if (action.equals("set")) {
      main.set(args[2], args[3], args[4], args[5]);
    }
  }

  /**
   * Delta aware getValue
   */
  private Object getBoardValue(Motherboard o, MtAttribute att) {
    if (!o.isNull(att))
      return o.getValue(att);
    if (o.getPreviousRevision() != null)
      return getBoardValue((Motherboard)o.getPreviousRevision(), att);
    if (o.getBranchOf() != null)
      return getBoardValue((Motherboard)o.getBranchOf(), att);
    return null;
  }
  private Object getChip1Value(Motherboard o, MtAttribute att) {
    if (!o.getChip1().isNull(att))
      return o.getChip1().getValue(att);
    if (o.getPreviousRevision() != null)
      return getChip1Value((Motherboard)o.getPreviousRevision(), att);
    if (o.getBranchOf() != null)
      return getChip1Value((Motherboard)o.getBranchOf(), att);
    return null;
  }
  private Object getChip2Value(Motherboard o, MtAttribute att) {
    if (!o.getChip2().isNull(att))
      return o.getChip2().getValue(att);
    if (o.getPreviousRevision() != null)
      return getChip2Value((Motherboard)o.getPreviousRevision(), att);
    if (o.getBranchOf() != null)
      return getChip2Value((Motherboard)o.getBranchOf(), att);
    return null;
  }
    
  /**
   * Indented print
   */
  private void println(String str, int indent) {
    for (int i=0; i<indent; i++)
      System.out.print("  ");
    System.out.println(str);
  }

  /**
   * Recursive revision dump
   */
  private void dump(Motherboard mb, int indent) {
    println("Motherboard V" + mb.getRevision() + " " + mb.getDate().getTime(), indent);
    println("|Param1="+getBoardValue(mb, Motherboard.getParam1Attribute(db)), indent);
    println("|Param2="+getBoardValue(mb, Motherboard.getParam2Attribute(db)), indent);
    println("|Param3="+getBoardValue(mb, Motherboard.getParam3Attribute(db)), indent);
    println("|Chip1.Param1="+getChip1Value(mb, Chip1.getParam1Attribute(db)), indent);
    println("|Chip1.Param2="+getChip1Value(mb, Chip1.getParam2Attribute(db)), indent);
    println("|Chip1.Param3="+getChip1Value(mb, Chip1.getParam3Attribute(db)), indent);
    println("|Chip1.Param4="+getChip1Value(mb, Chip1.getParam4Attribute(db)), indent);
    println("|Chip1.Param5="+getChip1Value(mb, Chip1.getParam5Attribute(db)), indent);
    println("|Chip2.Param1="+getChip2Value(mb, Chip2.getParam1Attribute(db)), indent);
    println("|Chip2.Param2="+getChip2Value(mb, Chip2.getParam2Attribute(db)), indent);
    println("|Chip2.Param3="+getChip2Value(mb, Chip2.getParam3Attribute(db)), indent);
    println("|Chip2.Param4="+getChip2Value(mb, Chip2.getParam4Attribute(db)), indent);
    Revisable branches[] = mb.getBranches();
    for (int i=0; i<branches.length; i++)
      dump((Motherboard)branches[i], indent+1);
    if (mb.getNextRevision() != null)
      dump((Motherboard)mb.getNextRevision(), indent);
  }
    
  /**
   * Dump all version content
   */
  public void dump(String startingPoint) {
    db.startVersionAccess();
    Motherboard base = (Motherboard)Revisable.lookupRevision(db, startingPoint);
    if (base == null)
      System.out.println("no such revision "+startingPoint);
    else
      dump(base, 0);
    db.endVersionAccess();  
  }

  /**
   * create a new revision of the motherboard at the startingPoint
   */
  private Motherboard checkout(String startingPoint)
    {
      Motherboard base = (Motherboard)Revisable.lookupRevision(db, startingPoint);
      if (base == null)
      {
        // Boostrap with startingPoint = "1"
        if (startingPoint.equals("1")) {
          base = new Motherboard(db);
          base.setDate(new GregorianCalendar());
          base.setRevision(startingPoint);
          base.setChip1(new Chip1(db));
          base.setChip2(new Chip2(db));
        } else
          System.out.println("no such revision "+startingPoint);
      }
      Motherboard mb = new Motherboard(db);
      mb.setDate(new GregorianCalendar());
      mb.setChip1(new Chip1(db));
      mb.setChip2(new Chip2(db));
      if (base.getNextRevision() == null) {
        base.setNextRevision(mb);
        int i = startingPoint.lastIndexOf(".");
        if (i==-1) {
          mb.setRevision("" + (Integer.parseInt(startingPoint)+1));
        } else {
          mb.setRevision(startingPoint.substring(0,i+1)+
                         (Integer.parseInt(startingPoint.substring(i+1))+1));
        }
      } else {
        base.appendBranches(mb);
        mb.setRevision(startingPoint+"."+base.getBranchesSize());
      }
      // The inverse relationships previousRevision and branchOf are automatically maintained by Matisse.
      return mb;
    }

  /**
   * Set a param value
   */
  public void set(String startingPoint, String part, String att, String val)
    {
      db.startTransaction();
      Motherboard mb = checkout(startingPoint);
      if (part.equals("Motherboard")) {
        if (att.equals("param1"))
          mb.setParam1(val);
        else if (att.equals("param2"))
          mb.setParam2(val);
        else
          System.out.println("no such param\n");
      } else if (part.equals("Chip1")) {
        if (att.equals("param1"))
          mb.getChip1().setParam1(val);
        else if (att.equals("param2"))
          mb.getChip1().setParam2(val);
        else if (att.equals("param2"))
          mb.getChip1().setParam2(val);
        else if (att.equals("param3"))
          mb.getChip1().setParam3(val);
        else if (att.equals("param4"))
          mb.getChip1().setParam4(val);
        else if (att.equals("param5"))
          mb.getChip1().setParam5(val);
        else
          System.out.println("no such param\n");
      } else if (part.equals("Chip2")) {
        if (att.equals("param1"))
          mb.getChip2().setParam1(val);
        else if (att.equals("param2"))
          mb.getChip2().setParam2(val);
        else if (att.equals("param2"))
          mb.getChip2().setParam2(val);
        else if (att.equals("param3"))
          mb.getChip2().setParam3(val);
        else if (att.equals("param4"))
          mb.getChip2().setParam4(val);
        else
          System.out.println("no such param\n");
      } else {
        System.out.println("no such component\n");
      }
      db.commit();
    }


}
