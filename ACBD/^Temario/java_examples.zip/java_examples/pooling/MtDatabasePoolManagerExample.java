/*
 *  Copyright (c) 1992-2014 Matisse Software Inc. All Rights Reserved.
 *
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 *
 */

import java.io.PrintWriter;
import java.lang.Thread;
import java.util.Random;

import com.matisse.MtException;
import com.matisse.MtDatabase;
import com.matisse.reflect.MtClass;


public class MtDatabasePoolManagerExample {

  private static final int maxConnections   = 8;   // number of connections
  private static final int defaultTimeout   = 1;   // wait timeout seconds to acquire free connection
  private static final int noOfThreads      = 50;  // number of worker threads
  private static final int processingTime   = 2;  // total processing time of the test program in seconds
  private static final int threadPauseTime1 = 100; // max. thread pause time in microseconds, without a connection
  private static final int threadPauseTime2 = 100; // max. thread pause time in microseconds, with a connection

  private static WorkerThread[] threads;
  private static boolean shutdownFlag;
  private static Object shutdownObj = new Object();
  private static Random random = new Random();

  private static MtDatabasePoolManager poolMgr;

  private static class WorkerThread extends Thread {
	public int threadNo;
	public void run() {
      threadMain (threadNo); 
	}
  };


  public static void main (String[] args) throws Exception {

    if (args.length < 2)
    {
      System.out.println("Need to specify <HOST> <DATABASE>");
      System.exit(-1);
    }

    String hostname = args[0];
    String dbname = args[1];

	// Create a connection pool manager
	createConnectionPoolManager(hostname, dbname);

	// Start all threads 
	startWorkerThreads();

	// Run the example for a few seconds
	pause (processingTime*1000000);

	// Stop all threads 
	stopWorkerThreads();

	// Dispose connection pool manager
	disposeConnectionPoolManager();
  }

  /** Create a connection pool manager */
  private static void createConnectionPoolManager(String hostname, String dbname) 
	throws MtException {
    System.out.println("=========== createConnectionPoolManager ==========\n");

	poolMgr = new MtDatabasePoolManager(hostname, dbname, maxConnections, 
                                        defaultTimeout);
	System.out.println ("Connection Pool Manager: " + poolMgr); 
  }

  /** Start all threads  */
  private static void startWorkerThreads() {
    System.out.println("=========== startWorkerThreads ==========\n");
	threads = new WorkerThread[noOfThreads];
	for (int threadNo=0; threadNo<noOfThreads; threadNo++) {
      WorkerThread thread = new WorkerThread();
      threads[threadNo] = thread;
      thread.threadNo = threadNo;
      thread.start(); 
	}
  }

  /** Stop all threads */
  private static void stopWorkerThreads() throws Exception {
    System.out.println("\n=========== stopWorkerThreads ==========\n");
	System.out.println("Connection active: " + poolMgr.getActiveConnections());
	setShutdownFlag();
	for (int threadNo = 0; threadNo < noOfThreads; threadNo++) {
      threads[threadNo].join(); 
	}
	System.out.println("Connection active: " + poolMgr.getActiveConnections());
  }

  /** Dispose connection pool manager */
  private static void disposeConnectionPoolManager() 
	throws MtException {
    System.out.println("=========== disposeConnectionPoolManager ==========\n");
	poolMgr.dispose();
  }
    
  private static void threadMain (int threadNo) {
	try {
      while (true) {
		if (!pauseRandom(threadPauseTime1)) return;
		threadTask (threadNo); 
      }
	} catch (Throwable e) {
      System.out.println ("\nException in thread "+ threadNo + ": " + e);
      e.printStackTrace();
      setShutdownFlag(); 
	}
  }

  private static void threadTask (int threadNo) throws Exception {
	MtDatabase conn = null;
	try {
      // Get a connection from the Pool
      conn = poolMgr.getConnection();

      if (shutdownFlag) return;

      long cnt = countSchemaClasses (conn, threadNo);
      System.out.print ("T"+ threadNo + "-C" + conn + "-V" + cnt + " ");

      pauseRandom (threadPauseTime2); 
	} catch (MtDatabasePoolManager.TimeoutException e) {
      System.out.print ("T"+ threadNo + "-Ctimeout ");
	} finally {
      // Release the connection back to the Pool
      if (conn != null) poolMgr.recycleConnection(conn); 
	}
  }

  private static boolean pauseRandom (int maxPauseTime) throws Exception {
	return pause (random.nextInt(maxPauseTime)); 
  }

  private static boolean pause (int pauseTime) throws Exception {
	synchronized (shutdownObj) {
      if (shutdownFlag) return false;
      if (pauseTime <= 0) return true;
      int ms = pauseTime / 1000;
      int ns = (pauseTime % 1000) * 1000;
      shutdownObj.wait (ms,ns); 
	}
	return true; 
  }

  private static void setShutdownFlag() {
	synchronized (shutdownObj) {
      shutdownFlag = true;
      shutdownObj.notifyAll(); 
	}
  }

  private static long countSchemaClasses (MtDatabase conn, int threadNo) 
	throws MtException {
	long cnt = 0;
	try {
      conn.startVersionAccess();
      MtClass cClass = MtClass.get(conn, "MtClass");
      cnt = cClass.getInstanceNumber();	    
	} finally {
      if (conn.isVersionAccessInProgress())
		conn.endVersionAccess();
	}
	return cnt;
  }

} 


