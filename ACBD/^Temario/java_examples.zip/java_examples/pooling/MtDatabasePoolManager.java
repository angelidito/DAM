/*
 *  Copyright (c) 1992-2014 Matisse Software Inc. All Rights Reserved.
 *
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 *
 */

import java.util.Stack;

import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import com.matisse.MtDatabase;
import com.matisse.MtException;


/**
 * simple MtDatabase pool manager.
 *
 */
public class MtDatabasePoolManager {
  private String hostname;
  private String database;
  private String username;
  private String password;
  private int maxConnections;
  private int timeout;
  private Semaphore cxnAvailable;
  private Stack<MtDatabase> recycledConnections;
  private int activeConnections;
  private boolean isDisposed;


  /**
   * Thrown in <code>getConnection()</code> when no free connection becomes available 
   * within <code>timeout</code> seconds.
   */
  public static class TimeoutException extends RuntimeException {
	private static final long serialVersionUID = 1;
	public TimeoutException () {
      super ("Timeout while waiting for a free database connection."); }}

  /**
   * Constructs a MtDatabasePoolManager object with a timeout of 10 seconds.
   * @param hostname        the host name (or IP address).
   * @param database        the database name.
   * @param dataSource      the data source for the connections.
   * @param maxConnections  the maximum number of connections.
   */
  public MtDatabasePoolManager (String hostname, String database, int maxConnections) {
	this (hostname, database, null, null, maxConnections, 10); 
  }

  /**
   * Constructs a MtDatabasePoolManager object with a timeout of 10 seconds.
   * @param hostname        the host name (or IP address).
   * @param database        the database name.
   * @param dataSource      the data source for the connections.
   * @param maxConnections  the maximum number of connections.
   * @param timeout         the maximum time in seconds to wait for a free connection.
   */
  public MtDatabasePoolManager (String hostname, String database, int maxConnections, 
                                int timeout) {
	this (hostname, database, null, null, maxConnections, timeout); 
  }

  /**
   * Constructs a MtDatabasePoolManager object.
   * @param hostname        the host name (or IP address).
   * @param database        the database name.
   * @param username        the user name, or <code>null</code>
   * @param password        the user's password, or <code>null</code>
   * @param maxConnections  the maximum number of connections.
   * @param timeout         the maximum time in seconds to wait for a free connection.
   */
  public MtDatabasePoolManager (String hostname, String database, String username, 
                                String password, int maxConnections, int timeout) {
	this.hostname = hostname;
	this.database = database;
	this.username = username;
	this.password = password;
	this.maxConnections = maxConnections;
	this.timeout = timeout;
	if (maxConnections < 1) 
      throw new IllegalArgumentException("Invalid maxConnections value.");
	cxnAvailable = new Semaphore(maxConnections, true);
	recycledConnections = new Stack<MtDatabase>();
  }

  /**
   * Closes all unused pooled connections.
   */
  public synchronized void dispose() throws MtException {
	if (isDisposed) return;
	isDisposed = true;
	MtException e = null;
	while (!recycledConnections.isEmpty()) {
      MtDatabase dbconn = recycledConnections.pop();
      try {
		dbconn.close(); 
      }
      catch (MtException e2) {
		if (e == null) e = e2; 
      }
	}
	if (e != null) throw e; 
  }

  /**
   * Retrieves a connection from the connection pool.
   * If <code>maxConnections</code> connections are already in use, the method
   * waits until a connection becomes available or <code>timeout</code> seconds elapsed.
   * When the application is finished using the connection, it must close it
   * in order to return it to the pool.
   * @return a new Connection object.
   * @throws TimeoutException when no connection becomes available within <code>timeout</code> seconds.
   */
  public MtDatabase getConnection() throws MtException {
	synchronized (this) {
      if (isDisposed) throw new IllegalStateException("Connection pool has been disposed."); 
	}
	try {
      if (!cxnAvailable.tryAcquire(timeout,TimeUnit.SECONDS))
		throw new TimeoutException(); 
	} catch (InterruptedException e) {
      throw new RuntimeException("Interrupted while waiting for a database connection.", e); 
	}
	boolean ok = false;
	try {
      MtDatabase conn = getPooledConnection();
      ok = true;
      return conn; 
	} finally {
      if (!ok) cxnAvailable.release(); 
	}
  }

  private synchronized MtDatabase getPooledConnection() throws MtException {
	if (isDisposed) throw new IllegalStateException("Connection pool has been disposed.");
	MtDatabase conn;
	if (!recycledConnections.empty()) {
      conn = recycledConnections.pop(); 
	} else {
      conn = new MtDatabase(hostname, database);
      conn.open(username, password);
	}
	activeConnections++;
	assertInnerState();
	return conn; 
  }

  public synchronized void recycleConnection (MtDatabase conn) {
	if (isDisposed) { 
      disposeConnection (conn); 
      return; 
	}
	if (activeConnections <= 0) throw new AssertionError();
	activeConnections--;
	cxnAvailable.release();
	recycledConnections.push (conn);
	assertInnerState(); 
  }

  private synchronized void disposeConnection (MtDatabase conn) {
	if (activeConnections <= 0) throw new AssertionError();
	activeConnections--;
	cxnAvailable.release();
	closeConnectionNoEx (conn);
	assertInnerState(); 
  }

  private void closeConnectionNoEx (MtDatabase conn) {
	try {
      conn.close(); 
	}
	catch (MtException e) {
	}
  }


  private void assertInnerState() {
	if (activeConnections < 0) 
      throw new AssertionError();
	if (activeConnections+recycledConnections.size() > maxConnections) 
      throw new AssertionError();
	if (activeConnections+cxnAvailable.availablePermits() > maxConnections) 
      throw new AssertionError(); 
  }

  /**
   * Returns the number of active (open) connections of this pool.
   * This is the number of <code>Connection</code> objects that have been
   * issued by <code>getConnection()</code> for which <code>Connection.close()</code>
   * has not yet been called.
   * @return the number of active connections.
   **/
  public synchronized int getActiveConnections() {
	return activeConnections; 
  }

  public String toString() {
	return "MtDatabasePoolManager:" + 
      "hostname=" + hostname +
      ";database=" + database +
      (username != null ? ";username=" + username : "") +
      (password != null ? ";password=" + password : "") +
      ";maxConnections="+ maxConnections +
      ";timeout=" + timeout;
  }


} 
