/*
 *  Copyright (c) 1992-2014 Matisse Software Inc. All Rights Reserved.
 *
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 *
 */

import java.util.Stack;

import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import java.io.PrintWriter;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.ConnectionPoolDataSource;
import javax.sql.ConnectionEvent;
import javax.sql.ConnectionEventListener;
import javax.sql.PooledConnection;


/**
 * simple standalone JDBC connection pool manager.
 *
 */
public class JdbcConnectionPoolManager {
  private ConnectionPoolDataSource dataSource;
  private int maxConnections;
  private int timeout;
  private PrintWriter logWriter;
  private Semaphore cxnAvailable;
  private Stack<PooledConnection> recycledConnections;
  private int activeConnections;
  private PoolConnectionEventListener poolConnectionEventListener;
  private boolean isDisposed;

  private class PoolConnectionEventListener implements ConnectionEventListener {
	public void connectionClosed (ConnectionEvent event) {
      PooledConnection pconn = (PooledConnection)event.getSource();
      pconn.removeConnectionEventListener (this);
      recycleConnection (pconn); 
	}
	public void connectionErrorOccurred (ConnectionEvent event) {
      PooledConnection pconn = (PooledConnection)event.getSource();
      pconn.removeConnectionEventListener (this);
      disposeConnection (pconn); 
	}
  }


  /**
   * Thrown in <code>getConnection()</code> when no free connection becomes available 
   * within <code>timeout</code> seconds.
   */
  public static class TimeoutException extends RuntimeException {
	private static final long serialVersionUID = 1;
	public TimeoutException () {
      super ("Timeout while waiting for a free database connection."); }}

  /**
   * Constructs a JdbcConnectionPoolManager object with a timeout of 10 seconds.
   * @param dataSource      the data source for the connections.
   * @param maxConnections  the maximum number of connections.
   */
  public JdbcConnectionPoolManager (ConnectionPoolDataSource dataSource, int maxConnections) {
	this (dataSource, maxConnections, 10); 
  }

  /**
   * Constructs a JdbcConnectionPoolManager object.
   * @param dataSource      the data source for the connections.
   * @param maxConnections  the maximum number of connections.
   * @param timeout         the maximum time in seconds to wait for a free connection.
   */
  public JdbcConnectionPoolManager (ConnectionPoolDataSource dataSource, int maxConnections, 
                                    int timeout) {
	this.dataSource = dataSource;
	this.maxConnections = maxConnections;
	this.timeout = timeout;
	try {
      logWriter = dataSource.getLogWriter(); 
	} catch (SQLException e) { }
	if (maxConnections < 1) 
      throw new IllegalArgumentException("Invalid maxConnections value.");
	cxnAvailable = new Semaphore(maxConnections, true);
	recycledConnections = new Stack<PooledConnection>();
	poolConnectionEventListener = new PoolConnectionEventListener(); 
  }

  /**
   * Closes all unused pooled connections.
   */
  public synchronized void dispose() throws SQLException {
	if (isDisposed) return;
	isDisposed = true;
	SQLException e = null;
	while (!recycledConnections.isEmpty()) {
      PooledConnection pconn = recycledConnections.pop();
      try {
		pconn.close(); 
      }
      catch (SQLException e2) {
		if (e == null) e = e2; 
      }
	}
	if (e != null) throw e; 
  }

  /**
   * Retrieves a connection from the connection pool.
   * If <code>maxConnections</code> connections are already in use, the method
   * waits until a connection becomes available or <code>timeout</code> seconds elapsed.
   * When the application is finished using the connection, it must close it
   * in order to return it to the pool.
   * @return a new Connection object.
   * @throws TimeoutException when no connection becomes available within <code>timeout</code> seconds.
   */
  public Connection getConnection() throws SQLException {
	synchronized (this) {
      if (isDisposed) throw new IllegalStateException("Connection pool has been disposed."); 
	}
	try {
      if (!cxnAvailable.tryAcquire(timeout,TimeUnit.SECONDS))
		throw new TimeoutException(); 
	} catch (InterruptedException e) {
      throw new RuntimeException("Interrupted while waiting for a database connection.", e); 
	}
	boolean ok = false;
	try {
      Connection conn = getPooledConnection();
      ok = true;
      return conn; 
	} finally {
      if (!ok) cxnAvailable.release(); 
	}
  }

  private synchronized Connection getPooledConnection() throws SQLException {
	if (isDisposed) throw new IllegalStateException("Connection pool has been disposed.");
	PooledConnection pconn;
	if (!recycledConnections.empty()) {
      pconn = recycledConnections.pop(); 
	} else {
      pconn = dataSource.getPooledConnection(); 
	}
	Connection conn = pconn.getConnection();
	activeConnections++;
	pconn.addConnectionEventListener (poolConnectionEventListener);
	assertInnerState();
	return conn; 
  }

  private synchronized void recycleConnection (PooledConnection pconn) {
	if (isDisposed) { 
      disposeConnection (pconn); 
      return; 
	}
	if (activeConnections <= 0) throw new AssertionError();
	activeConnections--;
	cxnAvailable.release();
	recycledConnections.push (pconn);
	assertInnerState(); 
  }

  private synchronized void disposeConnection (PooledConnection pconn) {
	if (activeConnections <= 0) throw new AssertionError();
	activeConnections--;
	cxnAvailable.release();
	closeConnectionNoEx (pconn);
	assertInnerState(); 
  }

  private void closeConnectionNoEx (PooledConnection pconn) {
	try {
      pconn.close(); 
	}
	catch (SQLException e) {
      log ("Error while closing database connection: "+e.toString()); 
	}
  }

  private void log (String msg) {
	String s = "JdbcConnectionPoolManager: "+ msg;
	try {
      if (logWriter == null)
		System.err.println (s);
      else
		logWriter.println (s); 
	} catch (Exception e) {}
  }

  private void assertInnerState() {
	if (activeConnections < 0) 
      throw new AssertionError();
	if (activeConnections+recycledConnections.size() > maxConnections) 
      throw new AssertionError();
	if (activeConnections+cxnAvailable.availablePermits() > maxConnections) 
      throw new AssertionError(); 
  }

  /**
   * Returns the number of active (open) connections of this pool.
   * This is the number of <code>Connection</code> objects that have been
   * issued by  <code>getConnection()</code> for which <code>Connection.close()</code>
   * has not yet been called.
   * @return the number of active connections.
   **/
  public synchronized int getActiveConnections() {
	return activeConnections; 
  }

  public String toString() {
	return "JdbcConnectionPoolManager:" + dataSource + ";maxConnections="+ maxConnections 
      + ";timeout=" + timeout;
  }


} 
