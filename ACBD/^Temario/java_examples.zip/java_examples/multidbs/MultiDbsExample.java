/*
 *  Copyright (c) 1992-2014 Matisse Software Inc. All Rights Reserved.
 *
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 *
 */

import java.util.GregorianCalendar;
import java.math.BigDecimal;
import java.util.Iterator;

import java.sql.SQLException;
import java.sql.Statement;

import com.matisse.MtDatabase;
import com.matisse.MtPackageObjectFactory;
import com.matisse.MtException;
import com.matisse.MtException;
import com.matisse.MtObjectIterator;

import examples.java_examples.multidbs.Person;
import examples.java_examples.multidbs.Employee;
import examples.java_examples.multidbs.Manager;


/**
 * This class shows how to access with the same application 2 logical databases
 * into the database physical database server.
 *
 */
public class MultiDbsExample {

  public static void main(String[] args) {
    if (args.length < 2)
    {
      System.out.println("Need to specify <HOST> <DATABASE>");
      System.exit(-1);
    }

    String hostname = args[0];
    String dbname = args[1];

    // Clear all the objects in 'db_one'
    clearObjects(hostname, dbname, "examples.java_examples.multidbs.db_one");

    // Clear all the objects in 'db_two'
    clearObjects(hostname, dbname, "examples.java_examples.multidbs.db_two");

    // Create a few objects in 'db_one'
	createObjects(hostname, dbname, "examples.java_examples.multidbs.db_one", 1000);

    // Create a few objects in 'db_two'
	createObjects(hostname, dbname, "examples.java_examples.multidbs.db_two", 2000);

	// lookup Objects from an Entry Point Dictionary with an Iterator in 'db_one'
	iterateEPDict(hostname, dbname, "examples.java_examples.multidbs.db_one");

	// lookup Objects from an Entry Point Dictionary with an Iterator in 'db_two'
	iterateEPDict(hostname, dbname, "examples.java_examples.multidbs.db_two");

	// lookup Objects from an Index in 'db_one'
	lookupObjects(hostname, dbname, "examples.java_examples.multidbs.db_one");

	// lookup Objects from an Index in 'db_two'
	lookupObjects(hostname, dbname, "examples.java_examples.multidbs.db_two");

    // Execute SQL Method Call in 'db_one'
    callSQLMethods(hostname, dbname, "examples.java_examples.multidbs.db_one", 1000);

    // Execute SQL Method Call in 'db_two'
    callSQLMethods(hostname, dbname, "examples.java_examples.multidbs.db_two", 2000);

  }

  /**
   * Execute a DELETE statement to clear all the objects
   */ 
  public static void clearObjects(String hostname, String dbname, String dbNamespace) {
    System.out.println("=========== ClearObjects ==========\n");

    try {
      // The third argument is given so that the connection object can find
      // the mapping between the Java classes, which are defined in the 
      // "examples.java_examples.multidbs" package and the schema classes 
      // defined in the 'dbNamespace' namespace.
      //
      MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("examples.java_examples.multidbs", dbNamespace));


      // Open the connection to the database and start a transaction
      db.open();
      // Start a transaction
      db.startTransaction();

      // Set the SQL CURRENT_NAMESPACE to 'dbNamespace' so there is
      // no need to use the full qualified names to acces the schema objects
      db.setSqlCurrentNamespace(dbNamespace);

      try {
        // Create an instance of Statement
        Statement stmt = db.createStatement();

        System.out.println("Deleting objects in " + dbNamespace);

        // Execute the DELETE statement
        boolean res = stmt.execute("DELETE FROM Person");

        // Clean up
        stmt.close();
      } catch (SQLException e) {
        System.out.println("SQLException:  " + e.getMessage());      
        e.printStackTrace();
      }

      // Commit the transaction
      db.commit();

      // Close the database connection
      db.close();

      System.out.println("\nDone.\n");
    } catch (MtException mte) {
      System.out.println("MtException : " + mte.getMessage());
      mte.printStackTrace();
    }
  }

  /**
   * Create a few objects for the database schema located in a specific namespace
   */ 
  public static void createObjects(String hostname, String dbname, String dbNamespace, int minId) {
    System.out.println("=========== createObjects ==========\n");

    try {
      // The third argument is given so that the connection object can find
      // the mapping between the Java classes, which are defined in the 
      // "examples.java_examples.multidbs" package and the schema classes 
      // defined in the 'dbNamespace' namespace.
      //
      MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("examples.java_examples.multidbs", dbNamespace));

      db.open();
      db.startTransaction();
    
      Manager m1 = new Manager(db);
      m1.setId(minId+1);
      m1.setFirstName("James");
      m1.setLastName("Jones");
      m1.setComment("weak needs have always hindered reality");
      m1.setGender("Male");
      m1.setCollegeGrad(true);
      m1.setHireDate(new GregorianCalendar());
      m1.setSalary(new BigDecimal("43"));
      // Set a relationship 
      // Need to report to someone since the relationship 
      // cardinality minimum is set to 1
      m1.setReportsTo(m1);
    
      Manager m2 = new Manager(db);
      m2.setId(minId+2);
      m2.setFirstName("Pamela");
      m2.setLastName("Ronaldson");
      m2.setComment("kill the goose that lays the golden egg");
	  m2.setGender("Female");
	  m2.setCollegeGrad(true);
      m2.setHireDate(new GregorianCalendar());
      m2.setSalary(new BigDecimal("42"));
      // Set a relationship 
      m2.setReportsTo(m1);
    
      Employee e = new Employee(db);
      e.setId(minId+3);
      e.setFirstName("Elmo");
      e.setLastName("Tuttle");
      e.setComment("kill two birds with one stone");
	  e.setGender("Male");
	  e.setCollegeGrad(false);
      e.setHireDate(new GregorianCalendar());
      e.setSalary(new BigDecimal("22"));
      // Set a relationship 
      e.setReportsTo(m2);
        
      // Set a relationship 
      m1.setAssistant(e);
      // Set a relationship 
      m2.setAssistant(e);

      System.out.println("Created objects in " + dbNamespace);
      System.out.println("  " + m1.getMtClass().getMtFullName() +
                         " OID=" + m1.getMtOid() + " " + m1.getFirstName() + " (id=" + m1.getId() + ")" +
                         " reports to " + m1.getReportsTo().getFirstName());
      System.out.println("  " + m2.getMtClass().getMtFullName() +
                         " OID=" + m2.getMtOid() + " " + m2.getFirstName() + " (id=" + m2.getId() + ")" +
                         " reports to " + m2.getReportsTo().getFirstName());
      System.out.println("  " + e.getMtClass().getMtFullName() +
                         " OID=" + e.getMtOid() + " " + e.getFirstName() + " (id=" + e.getId() + ")" +
                         " reports to " + e.getReportsTo().getFirstName());
      System.out.println("  " + m1.getMtClass().getMtFullName() +
                         " OID=" + m1.getMtOid() + " " + m1.getFirstName() + " (id=" + m1.getId() + ")" +
                         " assitant is " + m1.getAssistant().getFirstName());
      System.out.println("  " + m2.getMtClass().getMtFullName() +
                         " OID=" + m2.getMtOid() + " " + m2.getFirstName() + " (id=" + m2.getId() + ")" +
                         " assitant is " + m2.getAssistant().getFirstName());

      db.commit();
      db.close();
      System.out.println("\nDone.\n");
    } catch (MtException mte) {
      System.out.println("MtException : " + mte.getMessage());
      mte.printStackTrace();
    }
  }

  /**
   * lookup Objects from an Entry Point Dictionary with an Iterator
   */ 
  public static void iterateEPDict(String hostname, String dbname, String dbNamespace) {

    System.out.println("=========== iterateEPDict ==========\n");

    System.out.println("Accessing objects via Entry Point Dictionary in " + dbNamespace);
    try {
      // The third argument is given so that the connection object can find
      // the mapping between the Java classes, which are defined in the 
      // "examples.java_examples.multidbs" package and the schema classes 
      // defined in the 'dbNamespace' namespace.
      //
      MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("examples.java_examples.multidbs", dbNamespace));

      db.open();

      db.startVersionAccess();
      String searchstring = "kill";
      System.out.println("\nLooking for Persons with '" + searchstring + "' in the 'comment' text");

      long hits = 0;

      // open an iterator on the matching person objects
      MtObjectIterator<Person> pIter = Person.commentDictIterator(db, searchstring);
      Person p = null;
      while ((p = pIter.next()) != null) {
        System.out.println("  " + p.getMtClass().getMtFullName() +
                           " OID=" + p.getMtOid() + " " + p.getFirstName() + " " +
                           p.getLastName() + "(id=" + p.getId() + ")" );
        hits++;
      }
      System.out.println(hits + " Person(s) with 'comment' containing '" + searchstring + "'");
	    
      // Entry Point Dictionary is a compact index well suited for attribute 
      // with enumeration type values (i.e. TRUE/FALSE, Male/Female)
      System.out.println("\nLooking for College Graduate Persons");

      hits = 0;
      // open an iterator on the matching person objects
      pIter = Person.collegeGradDictIterator(db, "true");
      p = null;
      while ((p = pIter.next()) != null) {
        System.out.println("  " + p.getMtClass().getMtFullName() +
                           " OID=" + p.getMtOid() + " " + p.getFirstName() + " " +
                           p.getLastName() + "(id=" + p.getId() + ")" );
        hits++;
      }
      System.out.println(hits + " Person(s) with College Graduate degrees");
	    	    
      db.endVersionAccess();

      db.close();
      System.out.println("\nDone.\n");
    } catch (MtException mte) {
      System.out.println("MtException : " + mte.getMessage());
      mte.printStackTrace();
    }
  }
  /**
   * lookup Objects from an Index
   */ 
  public static void lookupObjects(String hostname, String dbname, String dbNamespace) {

    System.out.println("=========== lookupObjects ==========\n");

    String firstName = "Elmo";
    String lastName = "Tuttle";

    System.out.println("Accessing objects via Index in " + dbNamespace);
    try {
      // The third argument is given so that the connection object can find
      // the mapping between the Java classes, which are defined in the 
      // "examples.java_examples.multidbs" package and the schema classes 
      // defined in the 'dbNamespace' namespace.
      //
      MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("examples.java_examples.multidbs", dbNamespace));

      db.open();

      db.startVersionAccess();

      System.out.println("\nLooking for: " + firstName + " " +  lastName);

      // the lookup function returns null to represent no match
      Person p = Person.lookupPersonName(db, lastName, firstName);
      if (p != null)
      {
        System.out.println("  " + p.getMtClass().getMtFullName() +
                           " OID=" + p.getMtOid() + " " + p.getFirstName() + " " +
                           p.getLastName() + "(id=" + p.getId() + ")" );
      }
      else
      {
        System.out.println(" Nobody found");
      }

      db.endVersionAccess();

      db.close();
      System.out.println("\nDone.\n");
    } catch (MtException mte) {
      System.out.println("MtException : " + mte.getMessage());
      mte.printStackTrace();
    }
  }

  /** 
   * Execute SQL Method Calls 
   */
  public static void callSQLMethods(String hostname, String dbname, String dbNamespace, int minId)  {

    System.out.println("=========== Call SQL Methods ==========\n");

    System.out.println("Accessing objects via SQL Methods in " + dbNamespace);
    try {
      // The third argument is given so that the connection object can find
      // the mapping between the Java classes, which are defined in the 
      // "examples.java_examples.multidbs" package and the schema classes 
      // defined in the 'dbNamespace' namespace.
      //
      MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("examples.java_examples.multidbs", dbNamespace));

      // Open the connection to the database
      db.open();

      db.startVersionAccess();

      int id = minId+2;
      // "getPersonFullName" SQL Method call
      String res = Person.getPersonFullName(db, id);

      System.out.println("Person #" + id + " full name: " + res);

      String firstName = "Elmo";
      String lastName = "Tuttle";
      Person p = Person.lookupPersonName(db, lastName, firstName);

      // "GetFullName" SQL Method call
      res = p.getFullName();
	
      System.out.println("Person #" + p.getId() + " full name: " + res);

      db.endVersionAccess();
      // Close the database connection
      db.close();

      System.out.println("\nDone.\n");
    } catch (SQLException e) {
      System.out.println("SQLException:  " + e.getMessage());      
      e.printStackTrace();
    } catch (MtException mte) {
      System.out.println("MtException : " + mte.getMessage());
      mte.printStackTrace();
    }
  }


}
