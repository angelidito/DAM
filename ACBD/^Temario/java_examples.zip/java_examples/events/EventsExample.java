/*
 *  EventsExample.java
 *
 *  Copyright (c) 1992-2014 Matisse Software, Inc. All Rights Reserved.
 *
 * 
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 */


import com.matisse.MtDatabase;
import com.matisse.MtEvent;

/**
 * This examples illustrates Matisse Event Notification mechansim.
 * The sample application is divided in 2 sections. The first section 
 * is event selection and notification. The second section is event registration 
 * and event handling.
 */
public final class EventsExample {
  public static int TEMPERATURE_CHANGES_EVT = MtEvent.EVENT1;
  public static int RAINFALL_CHANGES_EVT = MtEvent.EVENT2;
  public static int HIMIDITY_CHANGES_EVT = MtEvent.EVENT3;
  public static int WINDSPEED_CHANGES_EVT = MtEvent.EVENT4;
    
  public static void main(String[] args) {

	if (args.length < 3) {
      System.out.println("EventsExample <HOST> <DATABASE> N|S");
      System.exit(1);
	}

	String hostname = args[0];
	String dbname = args[1];
	String operationType = args[2];
	if (operationType.compareToIgnoreCase("N") == 0) {
      // event selection and notification
      notifyOfChanges(hostname, dbname);
	} else {
      // event registration and event handling
      subscribeToChanges(hostname, dbname);
	}
  }

  /** Execute an event selection and notification */
  public static void notifyOfChanges(String hostname, String dbname)
    {
      System.out.println("\n\n=========== Notify Of Changes ==========\n");

      // wait a little ...
      System.out.println("waiting 3 seconds one or more subscribers can be started ...\n");
      try { Thread.sleep(3000); } catch (Exception e) {}

      MtDatabase dbcon = new MtDatabase(hostname, dbname);

      // Open the connection to the database
      dbcon.open();

      // Create a notifier Event
      MtEvent notifier = new MtEvent(dbcon);

      long eventSet;

      for (int i = 0; i < MAX_MEASURES; i++)
      {
        eventSet = 0;
        if (changeInTemperature(i)) eventSet |= TEMPERATURE_CHANGES_EVT;
        if (changeInRainfall(i)) eventSet |= RAINFALL_CHANGES_EVT;
        if (i % 2 == 0) eventSet |= HIMIDITY_CHANGES_EVT;
        if (i % 2 == 1) eventSet |= WINDSPEED_CHANGES_EVT;

		// Notify of some events
        notifier.notify(eventSet);

        System.out.println("Events (#" + (i+1) + ") posted:");
        if ((eventSet & TEMPERATURE_CHANGES_EVT) > 0) System.out.println("Change in temperature");
        if ((eventSet & RAINFALL_CHANGES_EVT) > 0) System.out.println("Change in rain fall");
        if ((eventSet & HIMIDITY_CHANGES_EVT) > 0) System.out.println("Change in humidity");
        if ((eventSet & WINDSPEED_CHANGES_EVT) > 0) System.out.println("Change in wind speed");

        // wait a little ...
        System.out.println("waiting 1 sec ...\n");
        try { Thread.sleep(1000); } catch (Exception e) {}
      }
      // Close the database connection
      dbcon.close();
    }

  /** Execute an event selection and notification */
  public static void subscribeToChanges(String hostname, String dbname)
    {
      System.out.println("\n\n=========== Notify Of Changes ==========\n");

      MtDatabase dbcon = new MtDatabase(hostname, dbname);

      // Open the connection to the database
      dbcon.open();

      // Create a subscriber Event
      MtEvent subscriber = new MtEvent(dbcon);

      // Subscribe to all 4 events
      long eventSet = TEMPERATURE_CHANGES_EVT |
	    RAINFALL_CHANGES_EVT |
	    HIMIDITY_CHANGES_EVT |
	    WINDSPEED_CHANGES_EVT;

      // Subscribe
      subscriber.subscribe(eventSet);

      System.out.println("Subscribed to 4 Events:");
      System.out.println("- TEMPERATURE_CHANGES");
      System.out.println("- RAINFALL_CHANGES");
      System.out.println("- HIMIDITY_CHANGES");
      System.out.println("- WINDSPEED_CHANGES\n");

      long triggeredEvents;
      int i = 1;
      while (i < 20) {
	    // Wait 1000 ms for events to be triggered 
	    // return 0 if not event is triggered until the timeout is reached
	    if ((triggeredEvents = subscriber.wait(1000)) != 0) {
          System.out.println("Events (#" + i + ") triggered:");
          System.out.println((((triggeredEvents & TEMPERATURE_CHANGES_EVT) > 0) ? "" : "No ") +
                             "Change in temperature");
          System.out.println((((triggeredEvents & RAINFALL_CHANGES_EVT) > 0) ? "" : "No ") +
                             "Change in rain fall");
          System.out.println((((triggeredEvents & HIMIDITY_CHANGES_EVT) > 0) ? "" : "No ") +
                             "Change in humidity");
          System.out.println((((triggeredEvents & WINDSPEED_CHANGES_EVT) > 0) ? "" : "No ") +
                             "Change in wind speed\n");
	    } else {
          System.out.println("No Event received after 1 sec\n");
	    }
	    i++;
      }

      System.out.println("Unsubscribe to 4 Events");
      // Unsubscribe to all 4 events
      subscriber.unsubscribe();

      // Close the database connection
      dbcon.close();
    }
    

  static int MAX_MEASURES = 12;
  static double[] tempMeasures = { 48.7, 52.2, 53.3, 55.6, 58.1, 61.5, 62.7, 63.7, 64.5, 61.0, 54.8, 49.4 };
  static double[] rainfallMeasures = { 4.72, 4.15, 3.40, 1.25, 0.54, 0.13, 0.04, 0.09, 0.28, 1.19, 3.31, 3.18 };

  static boolean changeInTemperature(int idx)
    {
      boolean res = true;

      if (idx > 0) {
	    res = (Math.abs(tempMeasures[idx] - tempMeasures[idx - 1]) > 2.5);
      }
      return res;
    }

  static boolean changeInRainfall(int idx)
    {
      boolean res = true;

      if (idx > 0) {
	    res = (Math.abs(rainfallMeasures[idx] - rainfallMeasures[idx - 1]) > 0.25);
      }
      return res;
    }

}
