/*
 *  Copyright (c) 1992-2014 Matisse Software Inc. All Rights Reserved.
 *
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 *
 */

import java.util.Vector;
import java.util.Iterator;

import com.matisse.MtDatabase;
import com.matisse.MtException;
import com.matisse.MtVersionIterator;

import examples.java_examples.chap_7.Person;

/**
 * A simple example application which creates a version for every
 * attribute change.
 *
 * Command line options control creating, updating, and listing versions
 */
public class VersionExample {

  /**
   * main function (no argument checking!)
   * usage :
   *   VersionExample <db>[@host] list
   *   VersionExample <db>[@host] dump
   *   VersionExample <db>[@host] set <id> {FirstName|LastName} <val>
   *   VersionExample <db>[@host] get <id> <att> <version>
   */
  public static void main(String[] args) {
    if (args.length < 2) {
      System.out.println("Need to specify <database> list|dump|set <id> <att> <val>|get <id> <att> <val>");
      System.exit(-1);
	}

    String action = args[1];
    
    if (action.equals("list")) {
      list(args[0]);
    } else if (action.equals("dump")) {
      dump(args[0]);
    } else if (action.equals("set")) {
      set(args[0], args[2], args[3], args[4]);
    } else if (action.equals("get")) {
      get(args[0], args[2], args[3], args[4]);
    }
  }

  /**
   * List all named versions of this database.
   */
  public static void list(String dbname) {
    System.out.println("=========== list ==========\n");

    try {
      MtDatabase db = new MtDatabase(dbname);
      db.open();
      db.startVersionAccess();
      Iterator<String> it = db.versionIterator();
      while (it.hasNext()) 
		System.out.println(it.next());
      db.endVersionAccess();
      db.close();

      System.out.println("\nDone.");
	} catch (MtException mte) {
      System.out.println("MtException : " + mte.getMessage());
      mte.printStackTrace();
	}
  }

  final static String VNAME_REFIX = "VerEx_";
    
  /**
   * Dump all instances of Person for all versions.
   */
  public static void dump(String dbname) {
    System.out.println("=========== dump ==========\n");

    Vector<String> versions = new Vector<String>();

    try {
      MtDatabase db = new MtDatabase(dbname);
      db.open();
      db.startVersionAccess();
      MtVersionIterator it = db.versionIterator();
      while (it.hasNext()) {
        String vname = it.next();
        //System.out.println("dump vname: " + vname + " - prefix : " + VNAME_REFIX);
        // keep only the versions created by this program
        if (vname.toUpperCase().startsWith(VNAME_REFIX.toUpperCase())) {
          versions.add(vname);
        }
      }
      it.close();
      db.endVersionAccess();  
    
      for (int i=0; i<versions.size(); i++) {
		String vname = versions.elementAt(i);
		// Opens a named version 
		db.startVersionAccess(vname);
		System.out.println("Version " + vname);
		Iterator<Person> pi = Person.instanceIterator(db);
		while (pi.hasNext()) {
          Person p = pi.next();
          System.out.println("\t"+p.getId()+": "+ p.getFirstName() + " " + p.getLastName());
		}
		db.endVersionAccess();
      }
      db.close();

      System.out.println("\nDone.");
	} catch (MtException mte) {
      System.out.println("MtException : " + mte.getMessage());
      mte.printStackTrace();
	}
  }

  /**
   * Set an attribute value, then do a named commit.
   */
  public static void set(String dbname, String idStr, String att, String val) {
    System.out.println("=========== set ==========\n");

    try {
      MtDatabase db = new MtDatabase(dbname);
      db.open();
      int id = Integer.parseInt(idStr);
      db.startTransaction();
      Person p = Person.lookupPersonId(db, id);
      if (p==null) {
		p = new Person(db);
		p.setId(id);
      }
      if (att.equals("FirstName"))
		p.setFirstName(val);
      if (att.equals("LastName"))
		p.setLastName(val);
      String vname = db.commit(VNAME_REFIX);
      System.out.println("New Version " + vname + " created");
      db.close();

      System.out.println("\nDone.");
	} catch (MtException mte) {
      System.out.println("MtException : " + mte.getMessage());
      mte.printStackTrace();
	}
  }

  /**
   * Get an attribute value for a particular object from a particular version.
   */
  public static void get(String dbname, String idStr, String att, String vname) {
    System.out.println("=========== get ==========\n");

    try {
      MtDatabase db = new MtDatabase(dbname);
      db.open();
      int id = Integer.parseInt(idStr);
      db.startVersionAccess(vname);
      Person p = Person.lookupPersonId(db, id);
      if (p==null) {
		System.out.println("No such id: " + id);
      } else {
		if (att.equals("FirstName"))
          System.out.println(p.getFirstName());
		if (att.equals("LastName"))
          System.out.println(p.getLastName());        
      }
      db.endVersionAccess();      
      db.close();

      System.out.println("\nDone.");
	} catch (MtException mte) {
      System.out.println("MtException : " + mte.getMessage());
      mte.printStackTrace();
	}
  }
    
}
