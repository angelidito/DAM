/*
 *  Copyright (c) 1992-2014 Matisse Software Inc. All Rights Reserved.
 *
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 *
 */

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.matisse.MtDatabase;
import com.matisse.MtException;

public class JDBCConnection {    

  public static void main(String[] args) {

    if (args.length < 2)
    {
      System.out.println("Need to specify <HOST> <DATABASE>");
      System.exit(-1);
    }

    String hostname = args[0];
    String dbname = args[1];

	// Build a JDBC connection
    connectFromJDBC(hostname, dbname);
	// Build a JDBC connection from a MtDatabase connection
    connectFromMtDatabase(hostname, dbname);
  }
    
  /**
   * Create a JDBC connection. (Does not require com.matisse.* import.
   */
  public static void connectFromJDBC(String host, String dbname) {
    System.out.println("=========== connectFromJDBC ==========\n");
    try {
      Class.forName("com.matisse.sql.MtDriver");

      String url = "jdbc:matisse://" + host + "/" + dbname;

      System.out.println("Query class names from the JDBC connection: " + url);

      Connection jcon = DriverManager.getConnection(url);

      // Regular JDBC access

      Statement stmt = jcon.createStatement();
      String query = "SELECT MtName FROM MtClass";
      ResultSet rs = stmt.executeQuery(query);
      System.out.println("Result from: " + query);
	    
      while (rs.next()) {
        System.out.println(rs.getString("MtName"));
      }
      System.out.println("\ndone.");
    } catch (ClassNotFoundException e) {
      System.out.println("Matisse JDBC Driver class not found, check your CLASSPATH");
    } catch (SQLException e) {
      System.out.println("SQLException thrown:  " + e.getMessage());
    }
  }
    
  /**
   * Create a JDBC connection obtained through a MtDatabase connection
   */
  public static void connectFromMtDatabase(String host, String dbname) {
    System.out.println("=========== connectFromMtDatabase ==========\n");

    try {
      MtDatabase db = new MtDatabase(host, dbname);

      db.open();
      System.out.println("Query class names from a JDBC connection obtained through a MtDatabase connection");
      Connection jcon = db.getJDBCConnection();
      try {
        // Regular JDBC access
        Statement stmt = jcon.createStatement();
		String query = "SELECT * FROM MtClass";
        ResultSet rs = stmt.executeQuery(query);
		System.out.println("Result from: " + query);

        while (rs.next()) {
          System.out.println(rs.getString("MtName"));
        }
        jcon.close();
        System.out.println("\ndone.");
      } catch (SQLException e) {
        System.out.println("SQLException thrown:  " + e.getMessage());      
      }
    } catch (MtException mte) {
      System.out.println("MtException : " + mte.getMessage());
	}
  }
}
