/*
 *  Copyright (c) 1992-2014 Matisse Software Inc. All Rights Reserved.
 *
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 *
 */

import com.matisse.MtDatabase;
import com.matisse.MtException;


class AdvancedConnect {
  static MtDatabase db;

  public static void main(String[] args) {

    if (args.length < 2)
    {
      System.out.println("Need to specify <HOST> <DATABASE>");
      System.exit(-1);
    }
    try
    {
      db = new MtDatabase(args[0],args[1]);
    
      if (System.getProperty("MT_MEM_TRANS") != null)
        db.setOption(MtDatabase.MEMORY_TRANSPORT, MtDatabase.ON);

      if (System.getProperty("MT_DATA_ACCESS") != null)
      {
        db.setOption(MtDatabase.DATA_ACCESS_MODE,
                     Integer.parseInt(System.getProperty("MT_DATA_ACCESS")));
      }
    
      db.open(System.getProperty("dbuser"),
              System.getProperty("dbpasswd"));

      start(isReadOnly());
      printState();

      end(); 
    
      db.close();
    }
    catch (MtException mte)
    {
      System.out.println("MtException : " + mte.getMessage());
    }
  }

  static void start(boolean readonly) {
    if (readonly) 
      db.startVersionAccess();
    else
      db.startTransaction();
  }
    
  static void end() {
    if (db.isVersionAccessInProgress())
      db.endVersionAccess();
    else if (db.isTransactionInProgress())
      db.commit();
    else
      System.out.println("No transaction/version access in progress");
  }

  static boolean isMemoryTransportOn() {
    return db.getOption(MtDatabase.TRANSPORT_TYPE) == MtDatabase.MEM_TRANSPORT;
  }

  static boolean isReadOnly()
    {
      return (db.getOption(MtDatabase.DATA_ACCESS_MODE) ==
              MtDatabase.DATA_READONLY);
    }

  static void printState() {
    if (!db.isConnectionOpen()) {
      dbmsg("not connected");
    } else {
      if (db.isTransactionInProgress())
        dbmsg("read-write transaction underway");
      else if (db.isVersionAccessInProgress())
        dbmsg("read-only version access underway");
      else
        dbmsg("no transaction underway");
    }
    dbmsg("MEMORY_TRANSPORT is " + (isMemoryTransportOn() ? "on" : "off"));

    dbmsg("DATA_ACESS_MODE is " +
          (isReadOnly() ? "readonly" : "readwrite"));
    
  }

  static void dbmsg(String msg) {
    System.out.println("database " + db.getName()
                       + " on server " + db.getHost()
                       + ":  " + msg);
  }
}
