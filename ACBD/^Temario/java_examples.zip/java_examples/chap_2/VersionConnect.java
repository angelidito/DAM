/*
 *  Copyright (c) 1992-2014 Matisse Software Inc. All Rights Reserved.
 *
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 *
 */

import com.matisse.MtDatabase;
import com.matisse.MtException;

class VersionConnect {
  public static void main(String[] args) {

    if (args.length < 2)
    {
      System.out.println("Need to specify <HOST> <DATABASE>");
      System.exit(-1);
    }

    try
    {
      MtDatabase db = new MtDatabase(args[0], args[1]);

      db.open();
      db.startVersionAccess();

      System.out.println("Connection and read-only access to "
                         + db.toString());

      // version connect (=>read-only access)
      db.endVersionAccess();
      db.close();
    }
    catch (MtException mte)
    {
      System.out.println("MtException : " + mte.getMessage());
    }
  }
}
