/*
 *  Copyright (c) 1992-2014 Matisse Software Inc. All Rights Reserved.
 *
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 *
 */

import java.util.Iterator;

import com.matisse.MtDatabase;
import com.matisse.MtException;
import com.matisse.MtVersionIterator;


public class VersionNavigation {

  public static void main(String[] args) {
    if (args.length < 2)
    {
      System.out.println("Need to specify <HOST> <DATABASE>");
      System.exit(-1);
    }

    try
    {
      MtDatabase db = new MtDatabase(args[0], args[1]);

      db.open();

      db.startTransaction();
      System.out.println("Version list before regular commit:");
      listVersions(db);
      // read/write access 
      db.commit();

      db.startTransaction();
      System.out.println("Version list after regular commit:");
      listVersions(db);
      // another read/write access
      String verName = db.commit("test");
      System.out.println("Commit to version named: " + verName);

      db.startVersionAccess();
      System.out.println("Version list after named commit:");
      listVersions(db);
      // read-only access on the latest version.
      db.endVersionAccess();

      db.startVersionAccess(verName);
      System.out.println("Sucessful access within version: " + verName);
      // read-only access on a named version. It's not possible to
      // access a named version in read/write (transaction) mode.
      db.endVersionAccess();
    
      db.close();
    }
    catch (MtException mte)
    {
      System.out.println("MtException : " + mte.getMessage());
    }
  }
    
  public static void listVersions(MtDatabase db) {
    MtVersionIterator i = db.versionIterator();
    while (i.hasNext()) {
      String versionName = i.next();
      System.out.println("\t" + versionName);
	}
	i.close();
  }
}
