/*
 *  Copyright (c) 1992-2014 Matisse Software Inc. All Rights Reserved.
 *
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 *
 */

import com.matisse.MtDatabase;
import com.matisse.MtException;


public class Connect {
  public static void main(String[] args) {

    if (args.length < 2)
    {
      System.out.println("Need to specify <HOST> <DATABASE>");
      System.exit(-1);
    }

    try
    {
      MtDatabase db = new MtDatabase(args[0], args[1]);

      db.open();
      db.startTransaction();

      System.out.println("Connection and read-write access to "
                         + db.toString());
      // read/write access

      db.commit();
      db.close();
    }
    catch (MtException mte)
    {
      System.out.println("MtException : " + mte.getMessage());
    }
  }
}
