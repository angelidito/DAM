/*
 *  Copyright (c) 1992-2014 Matisse Software Inc. All Rights Reserved.
 *
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 *
 */

import java.util.Iterator;

import com.matisse.MtDatabase;
import com.matisse.MtException;
import com.matisse.MtObjectIterator;

import examples.java_examples.chaps_4_5_6.Person;
import examples.java_examples.chaps_4_5_6.Employee;
import examples.java_examples.chaps_4_5_6.Manager;


/* Sample application which uses an entry-point dictionary associated
 * with the Person.comment attribute. This is a full-text dictionary,
 * so every word in the comment attribute will provide an entry point.
 */
class EPDictExample {

  public static void main(String[] args) {
    if (args.length < 3)
    {
      System.out.println("Need to specify <HOST> <DATABASE> <searchstring>");
      System.exit(-1);
    }

    String hostname = args[0];
    String dbname = args[1];
	String searchstring = args[2];

	// Create Objects
	createObjects(hostname, dbname);

	// lookup Objects from an Entry Point Dictionary with an Iterator
	iterateEPDict(hostname, dbname, searchstring);

	// lookup in an Entry Point Dictionary for the number of object matching the key
	lookupObjectsCount(hostname, dbname, searchstring);

	// lookup Objects from an Entry Point Dictionary
	lookupObjects(hostname, dbname, searchstring);

	// Delete Created Objects
	deleteObjects(hostname, dbname);

  }
    


  /**
   * Create Objects
   */ 
  public static void createObjects(String hostname, String dbname)
    {
      System.out.println("=========== createObjects ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chaps_4_5_6" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chaps_4_5_6"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the default MtPackageObjectFactory object manages the 
        // direct mapping between the Java class Person, which is defined in the 
        // "examples.java_examples.chaps_4_5_6" package and the schema class Person defined 
        // in the "examples.java_examples.chaps_4_5_6" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname);

	    db.open();

	    db.startTransaction();

        Person p = new Person(db);
        p.setFirstName("John");
        p.setLastName("Jones");
        p.setComment("weak needs have always hindered reality");
	    p.setGender("Male");
	    p.setCollegeGrad(true);

        p = new Person(db);
        p.setFirstName("Jane");
        p.setLastName("Jones");
        p.setComment("in reality weak knees hindered many");
	    p.setGender("Female");
	    p.setCollegeGrad(true);

        p = new Person(db);
        p.setFirstName("Paul");
        p.setLastName("Ronaldson");
        p.setComment("kill two birds with one stone");
	    p.setGender("Male");
	    p.setCollegeGrad(false);

        p = new Person(db);
        p.setFirstName("Pamela");
        p.setLastName("Ronaldson");
        p.setComment("kill the goose that lays the golden egg");
	    p.setGender("Female");
	    p.setCollegeGrad(true);

	    System.out.println("\n" + Person.getInstanceNumber(db) +
                           " Person(s) in the database.");

        MtObjectIterator<Person> pIter = Person.<Person>instanceIterator(db);
        while (pIter.hasNext()) {
          p = pIter.next();
          System.out.println("  " + p.getFirstName() + " "
                             + p.getLastName() + " says \"" + p.getComment() + "\"");

	    }
        pIter.close();
        
	    db.commit();

	    db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }
    }

  /**
   * lookup Objects from an Entry Point Dictionary with an Iterator
   */ 
  public static void iterateEPDict(String hostname, String dbname, 
                                   String searchstring)
    {
      System.out.println("=========== iterateEPDict ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chaps_4_5_6" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chaps_4_5_6"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the default MtPackageObjectFactory object manages the 
        // direct mapping between the Java class Person, which is defined in the 
        // "examples.java_examples.chaps_4_5_6" package and the schema class Person defined 
        // in the "examples.java_examples.chaps_4_5_6" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname);

	    db.open();

        db.startVersionAccess();

        System.out.println("\nLooking for Persons  with '" + searchstring + "' in the 'comment' text");

        long hits = 0;

        // open an iterator on the matching person objects
        MtObjectIterator<Person> pIter = Person.commentDictIterator(db, searchstring);
        Person person = null;
        while ((person = pIter.next()) != null) {
          System.out.println("  " + person.getFirstName() + " " +
                             person.getLastName());
          hits++;
	    }
        System.out.println(hits + " Person(s) with 'comment' containing '" + searchstring + "'");
	    
	    // Entry Point Dictionary is a compact index well suited for attribute 
	    // with enumeration type values (i.e. TRUE/FALSE, Male/Female)
        System.out.println("\nLooking for College Graduate Persons");

        hits = 0;
        // open an iterator on the matching person objects
	    pIter = Person.collegeGradDictIterator(db, "true");
	    person = null;
        while ((person = pIter.next()) != null) {
          System.out.println("  " + person.getFirstName() + " " +
                             person.getLastName());
          hits++;
	    }
        System.out.println(hits + " Person(s) with College Graduate degrees");
	    
        System.out.println("\nLooking for Persons filtered by gender");

        hits = 0;
        // open an iterator on the matching person objects
	    pIter = Person.genderDictIterator(db, "Male");
	    person = null;
        while ((person = pIter.next()) != null) {
          System.out.println("  " + person.getFirstName() + " " +
                             person.getLastName());
          hits++;
	    }
        System.out.println(hits + " Male Person(s)");
	    
        db.endVersionAccess();

	    db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }
    }



  /**
   * lookup in an Entry Point Dictionary for the number of object matching the key
   */ 
  public static void lookupObjectsCount(String hostname, String dbname, 
                                        String searchstring)
    {
      System.out.println("=========== lookupObjectsCount ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chaps_4_5_6" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chaps_4_5_6"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the default MtPackageObjectFactory object manages the 
        // direct mapping between the Java class Person, which is defined in the 
        // "examples.java_examples.chaps_4_5_6" package and the schema class Person defined 
        // in the "examples.java_examples.chaps_4_5_6" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname);

	    db.open();

        db.startVersionAccess();

        System.out.println("\nLooking for Persons  with '" + searchstring + "' in the 'comment' text");

	    long count = Person.getCommentDictDictionary(db).getObjectNumber(searchstring, null);
	    System.out.println(count + " matching object(s) retrieved");
	    
        System.out.println("\nLooking for College Graduate Persons");

	    count = Person.getCollegeGradDictDictionary(db).getObjectNumber("True", null);
	    System.out.println(count + " matching object(s) retrieved");

        System.out.println("\nLooking for Persons filtered by gender");

	    count = Person.getGenderDictDictionary(db).getObjectNumber("Male", null);
	    System.out.println(count + " matching object(s) retrieved");

        db.endVersionAccess();

	    db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }
    }


  /**
   * lookup Objects from an Entry Point Dictionary
   */ 
  public static void lookupObjects(String hostname, String dbname, 
                                   String searchstring)
    {
      System.out.println("=========== lookupObjects ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chaps_4_5_6" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chaps_4_5_6"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the default MtPackageObjectFactory object manages the 
        // direct mapping between the Java class Person, which is defined in the 
        // "examples.java_examples.chaps_4_5_6" package and the schema class Person defined 
        // in the "examples.java_examples.chaps_4_5_6" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname);

	    db.open();

        db.startVersionAccess();

        System.out.println("\nLooking for Persons with '" + searchstring + "' in the 'comment' text");

        // the lookup function returns null to represent no match
	    // if more than one match an exception is raised
        Person found = (Person)Person.getCommentDictDictionary(db).lookup(searchstring);
        if (found != null)
        {
          System.out.println(" found " + found.getFirstName() + " " +
                             found.getLastName());
        }
        else
        {
          System.out.println(" Nobody found");
        }

        db.endVersionAccess();

	    db.close();
 
	    System.out.println("\nDone.");
     } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }
    }

  /**
   * Delete Created Objects
   */ 
  public static void deleteObjects(String hostname, String dbname)
    {
      System.out.println("=========== deleteObjects ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chaps_4_5_6" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chaps_4_5_6"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the default MtPackageObjectFactory object manages the 
        // direct mapping between the Java class Person, which is defined in the 
        // "examples.java_examples.chaps_4_5_6" package and the schema class Person defined 
        // in the "examples.java_examples.chaps_4_5_6" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname);

	    db.open();

	    db.startTransaction();

	    // List all Person objects
	    System.out.println("\n" + Person.getInstanceNumber(db) +
                           " Person(s) in the database.");
	    System.out.println("Removing...");
	    // Retrieve the object from the previous transaction
	    Iterator<Person> iter = Person.instanceIterator(db);
	    while (iter.hasNext()) {
          Person e = iter.next();
          // Remove created objects
          // NOTE: does not remove the object sub-parts
          //e.remove();
		    
          // To remove object sub-parts Overrides MtObject.deepRemove() 
          e.deepRemove();
	    }
	    System.out.println("Done");
	    System.out.println("\n" + Person.getInstanceNumber(db) +
                           " Person(s) in the database.");
	    db.commit();

	    db.close();
 
	    System.out.println("\nDone.");
     } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }
    }
}
