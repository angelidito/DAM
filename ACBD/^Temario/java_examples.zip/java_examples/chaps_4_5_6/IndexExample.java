/*
 *  Copyright (c) 1992-2014 Matisse Software Inc. All Rights Reserved.
 *
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 *
 */

import java.util.Iterator;

import com.matisse.MtDatabase;
import com.matisse.MtException;
import com.matisse.MtObjectIterator;

import examples.java_examples.chaps_4_5_6.Person;
import examples.java_examples.chaps_4_5_6.Employee;
import examples.java_examples.chaps_4_5_6.Manager;

// Sample application which uses an index for lookup and sorted listing.
class IndexExample {

  public static void main(String[] args) {
    if (args.length < 4)
    {
      System.out.println("Need to specify <HOST> <DATABASE> <firstName> <lastName>" );
      System.exit(-1);
    }

    String hostname = args[0];
    String dbname = args[1];

	// search for a Person with specified first and last names
	String firstName = args[2];
	String lastName = args[3];

	// Create Objects
	createObjects(hostname, dbname);

	// lookup Objects from an Index
	lookupObjects(hostname, dbname, firstName, lastName);

	// lookup Objects from an Index with an iterator
	iterateIndex(hostname, dbname);

	// lookup in an Index for the number of object matching the key
	lookupObjectsCount(hostname, dbname, firstName, lastName);

	// count the number of Entries in an Index
	countIndexEntries(hostname, dbname);

	// Delete Created Objects
	deleteObjects(hostname, dbname);
  }


  /**
   * Create Objects
   */ 
  public static void createObjects(String hostname, String dbname)
    {
      System.out.println("=========== createObjects ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chaps_4_5_6" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chaps_4_5_6"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the default MtPackageObjectFactory object manages the 
        // direct mapping between the Java class Person, which is defined in the 
        // "examples.java_examples.chaps_4_5_6" package and the schema class Person defined 
        // in the "examples.java_examples.chaps_4_5_6" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname);

	    db.open();

	    db.startTransaction();
        Person p1 = new Person(db);
        p1.setFirstName("John");
        p1.setLastName("Jones");
        Person p2 = new Person(db);
        p2.setFirstName("Fred");
        p2.setLastName("Jones");
        Person p3 = new Person(db);
        p3.setFirstName("John");
        p3.setLastName("Murray");
        Person p4 = new Person(db);
        p4.setFirstName("Fred");
        p4.setLastName("Flintstone");

	    System.out.println("\n" + Person.getInstanceNumber(db) +
                           " Person(s) in the database.");

        MtObjectIterator<Person> pIter = Person.<Person>instanceIterator(db);
        while (pIter.hasNext()) {
          Person p = pIter.next();
          System.out.println(" " + p.getFirstName() + " " +
                             p.getLastName());
	    }
        pIter.close();
        
	    db.commit();

	    db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }
    }

  /**
   * lookup Objects from an Index
   */ 
  public static void lookupObjects(String hostname, String dbname, 
                                   String firstName, String lastName)
    {
      System.out.println("=========== lookupObjects ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chaps_4_5_6" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chaps_4_5_6"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the default MtPackageObjectFactory object manages the 
        // direct mapping between the Java class Person, which is defined in the 
        // "examples.java_examples.chaps_4_5_6" package and the schema class Person defined 
        // in the "examples.java_examples.chaps_4_5_6" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname);

	    db.open();

        db.startVersionAccess();

        System.out.println("\nLooking for: " + firstName + " " +
                           lastName);

        // the lookup function returns null to represent no match
        Person found = Person.lookupPersonName(db, lastName, firstName);
        if (found != null)
        {
          System.out.println(" found " + found.getFirstName() + " " +
                             found.getLastName());
        }
        else
        {
          System.out.println(" Nobody found");
        }

        db.endVersionAccess();

	    db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }
    }

  /**
   * lookup Objects from an Index with an iterator
   */ 
  public static void iterateIndex(String hostname, String dbname)
    {
      System.out.println("=========== iterateIndex ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chaps_4_5_6" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chaps_4_5_6"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the default MtPackageObjectFactory object manages the 
        // direct mapping between the Java class Person, which is defined in the 
        // "examples.java_examples.chaps_4_5_6" package and the schema class Person defined 
        // in the "examples.java_examples.chaps_4_5_6" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname);

	    db.open();

        db.startVersionAccess();

        // open an iterator for a specific range
        String fromFirstName = "Fred";
        String toFirstName = "John";
        String fromLastName = "Jones";
        String toLastName = "Murray";
        System.out.println("\nLookup from \"" +
                           fromFirstName + " " + fromLastName + "\" to \"" +
                           toFirstName + " " + toLastName + "\"");

        MtObjectIterator<Person> ppIter = Person.<Person>personNameIterator(db,
                                                                            fromLastName, fromFirstName, 
                                                                            toLastName, toFirstName);
        while (ppIter.hasNext()) {
          Person p = ppIter.next();
          System.out.println("  " + p.getFirstName() + " " +
                             p.getLastName());
        }
        ppIter.close();

        db.endVersionAccess();

	    db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }
    }

  /**
   * lookup in an Index for the number of objects matching the key
   */ 
  public static void lookupObjectsCount(String hostname, String dbname, 
                                        String firstName, String lastName)
    {
      System.out.println("=========== lookupObjectsCount ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chaps_4_5_6" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chaps_4_5_6"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the default MtPackageObjectFactory object manages the 
        // direct mapping between the Java class Person, which is defined in the 
        // "examples.java_examples.chaps_4_5_6" package and the schema class Person defined 
        // in the "examples.java_examples.chaps_4_5_6" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname);

	    db.open();

        db.startVersionAccess();
        System.out.println("Looking for: " + firstName + " " + lastName);

	    Object[] key = new Object[] { lastName, firstName } ;
	    long count = Person.getPersonNameIndex(db).getObjectNumber(key);
	    System.out.println(count + " objects retrieved");

        db.endVersionAccess();

	    db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }
    }

  /**
   * count the number of Entries in an Index
   */ 
  public static void countIndexEntries(String hostname, String dbname)
    {
      System.out.println("=========== countIndexEntries ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chaps_4_5_6" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chaps_4_5_6"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the default MtPackageObjectFactory object manages the 
        // direct mapping between the Java class Person, which is defined in the 
        // "examples.java_examples.chaps_4_5_6" package and the schema class Person defined 
        // in the "examples.java_examples.chaps_4_5_6" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname);

	    db.open();

        db.startVersionAccess();

	    long count = Person.getPersonNameIndex(db).getIndexEntriesNumber();
	    System.out.println(count + " entries in the index");

        db.endVersionAccess();

	    db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }
    }

  /**
   * Delete Created Objects
   */ 
  public static void deleteObjects(String hostname, String dbname)
    {
      System.out.println("=========== deleteObjects ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chaps_4_5_6" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chaps_4_5_6"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the default MtPackageObjectFactory object manages the 
        // direct mapping between the Java class Person, which is defined in the 
        // "examples.java_examples.chaps_4_5_6" package and the schema class Person defined 
        // in the "examples.java_examples.chaps_4_5_6" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname);

	    db.open();

	    db.startTransaction();

	    // List all Person objects
	    System.out.println("\n" + Person.getInstanceNumber(db) +
                           " Person(s) in the database.");
	    System.out.println("Removing...");
	    // Retrieve the object from the previous transaction
	    Iterator<Person> iter = Person.<Person>instanceIterator(db);
	    while (iter.hasNext()) {
          Person e = iter.next();
          // Remove created objects
          // NOTE: does not remove the object sub-parts
          //e.remove();
		    
          // To remove object sub-parts Overrides MtObject.deepRemove() 
          e.deepRemove();
	    }
	    System.out.println("Done");
	    System.out.println("\n" + Person.getInstanceNumber(db) +
                           " Person(s) in the database.");
	    db.commit();

	    db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }
    }
}
