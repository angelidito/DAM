/*
 *  Copyright (c) 1992-2014 Matisse Software Inc. All Rights Reserved.
 *
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 *
 */

import java.util.GregorianCalendar;
import java.math.BigDecimal;
import java.util.Iterator;

import com.matisse.MtDatabase;
import com.matisse.MtException;

import examples.java_examples.chaps_4_5_6.Person;
import examples.java_examples.chaps_4_5_6.Employee;
import examples.java_examples.chaps_4_5_6.Manager;

/**
 * This class shows how to access, modify, and navigate relationships.
 *
 */
public class RelationshipsExample {

  public static void main(String[] args) {
    if (args.length < 2)
    {
      System.out.println("Need to specify <HOST> <DATABASE>");
      System.exit(-1);
    }

    String hostname = args[0];
    String dbname = args[1];

	// Set Relationships between objects
	setRelationships(hostname, dbname);

	// Add Objects to a Relationship
	addToARelationship(hostname, dbname);

	// Remove Objects from a Relationship
	removeFromRelationship(hostname, dbname);

	// Iterate through a Relationship
	iterateRelationship(hostname, dbname);

	// Get the Relationship Size
	getRelationshipSize(hostname, dbname);

	// compare Objects from a Relationship
	compareObjectsFromRelationship(hostname, dbname);

	// Delete Created Objects
	deleteObjects(hostname, dbname);

  }

  /**
   * Set Relationships between objects
   */ 
  public static void setRelationships(String hostname, String dbname)
    {
      System.out.println("=========== setRelationships ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chaps_4_5_6" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chaps_4_5_6"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the default MtPackageObjectFactory object manages the 
        // direct mapping between the Java class Person, which is defined in the 
        // "examples.java_examples.chaps_4_5_6" package and the schema class Person defined 
        // in the "examples.java_examples.chaps_4_5_6" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname);

        db.open();
        db.startTransaction();
    
        Manager m1 = new Manager(db);
        m1.setFirstName("James");
        m1.setLastName("Dithers");
        m1.setHireDate(new GregorianCalendar());
        m1.setSalary(new BigDecimal("43"));
	    // Set a relationship 
	    // Need to report to someone since the relationship 
	    // cardinality minimum is set to 1
        m1.setReportsTo(m1);
    
        Manager m2 = new Manager(db);
        m2.setFirstName("Dagwood");
        m2.setLastName("Bumstead");
        m2.setHireDate(new GregorianCalendar());
        m2.setSalary(new BigDecimal("42"));
	    // Set a relationship 
        m2.setReportsTo(m1);
    
        Employee e = new Employee(db);
        e.setFirstName("Elmo");
        e.setLastName("Tuttle");
        e.setHireDate(new GregorianCalendar());
        e.setSalary(new BigDecimal("22"));
	    // Set a relationship 
        e.setReportsTo(m2);
        
	    // Set a relationship 
        m1.setAssistant(e);
	    // Set a relationship 
        m2.setAssistant(e);

        System.out.println("\nInitial settings:");
	    System.out.println("\t" + m1.getMtClass().getMtName() + " " + 
                           m1.getFirstName() + " reports to " + m1.getReportsTo().getFirstName());
	    System.out.println("\t" + m2.getMtClass().getMtName() + " " + 
                           m2.getFirstName() + " reports to " + m2.getReportsTo().getFirstName());
	    System.out.println("\t" + e.getMtClass().getMtName() + " " + 
                           e.getFirstName() + " reports to " + e.getReportsTo().getFirstName());
	    System.out.println("\t" + m1.getMtClass().getMtName() + " " + 
                           m1.getFirstName() + " assitant is " + m1.getAssistant().getFirstName());
	    System.out.println("\t" + m2.getMtClass().getMtName() + " " + 
                           m2.getFirstName() + " assitant is " + m2.getAssistant().getFirstName());


        System.out.println("\nInverse relationships are automatically updated:");
        // team is automatically updated
        Employee[] team = m1.getTeam();
	    System.out.print("\t" + m1.getFirstName() + " team is: ");
	    for (int i=0; i<team.length; i++)
          System.out.print(" " + team[i].getFirstName());
        System.out.println("\n");

        // assistantOf is automatically updated
	    Manager[] assistants = e.getAssistantOf();
        for (int i=0; i<assistants.length; i++)
          System.out.println("\t" + e.getFirstName() + " is " 
                             + assistants[i].getFirstName() + "'s assistant");

        db.commit();
        db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }
    }


  /**
   * Add Objects to a Relationship
   */ 
  public static void addToARelationship(String hostname, String dbname)
    {
      System.out.println("=========== addToARelationship ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chaps_4_5_6" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chaps_4_5_6"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the default MtPackageObjectFactory object manages the 
        // direct mapping between the Java class Person, which is defined in the 
        // "examples.java_examples.chaps_4_5_6" package and the schema class Person defined 
        // in the "examples.java_examples.chaps_4_5_6" namespace
        //
        MtDatabase db = new MtDatabase(hostname, dbname);

        db.open();
        db.startTransaction();

        Manager m2 = (Manager)Person.lookupPersonName(db, "Bumstead", "Dagwood");

        Person c1 = new Person(db);
        c1.setFirstName("Alexander");
        c1.setLastName("Bumstead");
    
        Person c2 = new Person(db);
        c2.setFirstName("Cookie");
        c2.setLastName("Bumstead");
    
        // Set successors
        m2.setChildren(new Person[] {c1, c2});

        // father is automatically updated 
        System.out.println("\nSet successors:");
        System.out.println("\t" + c1.getFirstName() + " is " 
                           + c1.getFather().getFirstName() + "'s child");
        System.out.println("\t" + c2.getFirstName() + " is " 
                           + c2.getFather().getFirstName() + "'s child");
    
        Person c3 = new Person(db); 
        c3.setFirstName("Baby");
        c3.setLastName("Bumstead");
    
        // add successors
        m2.appendChildren(new Person[] {c3});
    
        System.out.println("\nAdd another successor:");
        System.out.println("\tNow " + m2.getFirstName() + " has " 
                           + m2.getChildren().length + " children");

        db.commit();
        db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }
    }

  /**
   * Remove Objects from a Relationship
   */ 
  public static void removeFromRelationship(String hostname, String dbname)
    {
      System.out.println("=========== removeFromRelationship ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chaps_4_5_6" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chaps_4_5_6"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the default MtPackageObjectFactory object manages the 
        // direct mapping between the Java class Person, which is defined in the 
        // "examples.java_examples.chaps_4_5_6" package and the schema class Person defined 
        // in the "examples.java_examples.chaps_4_5_6" namespace
        //
        MtDatabase db = new MtDatabase(hostname, dbname);

        db.open();
        db.startTransaction();
    
        Manager m2 = (Manager)Person.lookupPersonName(db, "Bumstead", "Dagwood");
        Person c2 = Person.lookupPersonName(db, "Bumstead", "Cookie");

        // removing successors (this only breaks links, it does not
        // remove objects)
        m2.removeChildren(new Person[] {c2});
        System.out.println("\nRemove one successor:");
        System.out.println("\tNow " + m2.getFirstName() + " has " 
                           + m2.getChildren().length + " children");

        // clearing all successors (this only breaks links, it does
        // not remove objects)
        m2.clearChildren();
        System.out.println("\nClear successors:");
        System.out.println("\tNow " + m2.getFirstName() + " has " 
                           + m2.getChildren().length + " children");

	    // NOTE: rollback changes so next sample can still see 3 children
        db.rollback();

        db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }
    }

  /**
   * Iterate through a Relationship
   */ 
  public static void iterateRelationship(String hostname, String dbname)
    {
      System.out.println("=========== iterateRelationship ==========\n");

      try {
        MtDatabase db = new MtDatabase(hostname, dbname);

        db.open();

	    //read-only access
	    db.startVersionAccess();

        Manager m2 = (Manager)Person.lookupPersonName(db, "Bumstead", "Dagwood");


        System.out.println("\nIterate:");
        System.out.print("\t" + m2.getFirstName() + "'s children:");

        // Iterate when the relationship is large is always more efficient
        Iterator<Person> i = m2.childrenIterator();
        while (i.hasNext())
          System.out.print(" "+i.next().getFirstName());
        System.out.println("\n");

	    db.endVersionAccess();

        db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }
    }

  /**
   * Get the Relationship Size
   */ 
  public static void getRelationshipSize(String hostname, String dbname)
    {
      System.out.println("=========== getRelationshipSize ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chaps_4_5_6" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chaps_4_5_6"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the default MtPackageObjectFactory object manages the 
        // direct mapping between the Java class Person, which is defined in the 
        // "examples.java_examples.chaps_4_5_6" package and the schema class Person defined 
        // in the "examples.java_examples.chaps_4_5_6" namespace
        //
        MtDatabase db = new MtDatabase(hostname, dbname);

        db.open();
        db.startTransaction();

        Manager m2 = (Manager)Person.lookupPersonName(db, "Bumstead", "Dagwood");

	    // Get the relationship size without loading the Java objects
	    // which is the fast way to get the size 
	    int childrenCnt = m2.getChildrenSize();

        System.out.println("\t" + m2.getFirstName() + " has " + childrenCnt + " children");

	    // an alternative to get the relationship size 
	    // but the Java objects are loaded before you can get the count
	    childrenCnt = m2.getChildren().length;

        System.out.println("\t" + m2.getFirstName() + " has " + childrenCnt + " children");


	    // NOTE: rollback changes so next sample can still see 3 children
        db.rollback();

        db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }
    }

  /**
   * compare Objects from a Relationship
   */ 
  public static void compareObjectsFromRelationship(String hostname, String dbname)
    {
      System.out.println("=========== compareObjectsFromRelationship ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chaps_4_5_6" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chaps_4_5_6"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the default MtPackageObjectFactory object manages the 
        // direct mapping between the Java class Person, which is defined in the 
        // "examples.java_examples.chaps_4_5_6" package and the schema class Person defined 
        // in the "examples.java_examples.chaps_4_5_6" namespace
        //
        MtDatabase db = new MtDatabase(hostname, dbname);

        db.open();
        db.startTransaction();

        Manager m2 = (Manager)Person.lookupPersonName(db, "Bumstead", "Dagwood");

	    Person children[] = m2.getChildren();
	    Person c1 = children[0];
	    Person c2 = children[1];

        // Use "equals" (not ==) to compare objects
        System.out.println("\nCompare objects with equals() and not with == :");

        // returns incorrect 'False'
        System.out.println("\tDo " + c1.getFirstName() + " and " +
                           c2.getFirstName() +  " have the same father (==)?     " 
                           + (c1.getFather() == c2.getFather()));

        // returns 'True'
        System.out.println("\tDo " + c1.getFirstName() + " and " +
                           c2.getFirstName() + " have the same father (equals)? " 
                           + c1.getFather().equals(c2.getFather()));
    
	    // NOTE: rollback changes so next sample can still see 3 children
        db.rollback();

        db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }
    }

  /**
   * Delete Created Objects
   */ 
  public static void deleteObjects(String hostname, String dbname)
    {
      System.out.println("=========== deleteObjects ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chaps_4_5_6" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chaps_4_5_6"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the default MtPackageObjectFactory object manages the 
        // direct mapping between the Java class Person, which is defined in the 
        // "examples.java_examples.chaps_4_5_6" package and the schema class Person defined 
        // in the "examples.java_examples.chaps_4_5_6" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname);

	    db.open();

	    db.startTransaction();

	    // List all Person objects
	    System.out.println("\n" + Person.getInstanceNumber(db) +
                           " Person(s) in the database.");
	    System.out.println("Removing...");
	    // Retrieve the object from the previous transaction
	    Iterator<Person> iter = Person.instanceIterator(db);
	    while (iter.hasNext()) {
          Person e = iter.next();
          // Remove created objects
          // NOTE: does not remove the object sub-parts
          //e.remove();
		    
          // To remove object sub-parts Overrides MtObject.deepRemove() 
          e.deepRemove();
	    }
	    System.out.println("Done");
	    System.out.println("\n" + Person.getInstanceNumber(db) +
                           " Person(s) in the database.");
	    db.commit();

	    db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }

    }
}
