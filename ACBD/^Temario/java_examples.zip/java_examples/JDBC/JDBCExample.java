/*
 *  JDBCExample.cs
 *
 *  Copyright (c) 2002-2013 Matisse Software, Inc. All Rights Reserved.
 *
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 */

import java.util.Iterator;
import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import com.matisse.MtDatabase;
import com.matisse.MtPackageObjectFactory;
import com.matisse.MtException;
import com.matisse.reflect.MtType;

import com.matisse.sql.MtStatement;
import com.matisse.sql.MtCallableStatement;
import com.matisse.sql.MtPreparedStatement;
import com.matisse.sql.MtResultSet;

import examples.java_examples.jdbc.Person;
import examples.java_examples.jdbc.Employee;
import examples.java_examples.jdbc.Manager;


/**
 * This class shows how to use JDBC with Matisse.
 *
 */
public class JDBCExample
{
  public static void main(String[] args) {
    if (args.length < 2)
    {
      System.out.println("Need to specify <HOST> <DATABASE>");
      System.exit(1);
    }

    String hostname = args[0];
    String dbname = args[1];

    // Clear all the Person objects
    ClearPersonObjects(hostname, dbname);

    // Execute INSERT statement using ExecuteNonQuery()
    InsertObjects(hostname, dbname);

    // Execute SELECT statement and read returned values
    DataReaderValues(hostname, dbname);

    // Execute SELECT statement and get the selected objects
    DataReaderObjects(hostname, dbname);

    // Execute a block statement, and get the returned object selection
    ExecuteBlockStatement(hostname, dbname);

    // Parse SQL statements and get their types
    ParseSQLQuery(hostname, dbname);

    // Create stored methods, which will be used in the following examples
    CreateStoredMethod(hostname, dbname);

    // Call a stored method, and get the returned value
    CallStoredMethod1(hostname, dbname);

    // Call a stored method, and get the returned OBJECT
    CallStoredMethod2(hostname, dbname);

    // Call a stored method, and get an execution stack trace
    CallStoredMethod3(hostname, dbname);

  }
    
  /**
   * Execute a DELETE statement to clear all the Person objects
   */ 
  public static void ClearPersonObjects(String hostname, String dbname)
    {
      System.out.println("=========== ClearPersonObjects ==========\n");

      MtDatabase dbcon = new MtDatabase(hostname, dbname);

      // Open the connection to the database and start a transaction
      dbcon.open();
      // Start a transaction
      dbcon.startTransaction();

      try {
	    // Create an instance of Statement
	    Statement stmt = dbcon.createStatement();

        String stmtTxt = "DELETE FROM examples.java_examples.jdbc.Person";
	    System.out.println("Query Text: " + stmtTxt);
	    // Execute the DELETE statement
	    boolean res = stmt.execute(stmtTxt);

	    // Clean up
	    stmt.close();
      } catch (SQLException e) {
	    System.out.println("SQLException:  " + e.getMessage());      
      }

      // Commit the transaction
      dbcon.commit();

      // Close the database connection
      dbcon.close();

      System.out.println("Done.\n");
    }

  /**
   * Execute an INSERT statement with parameters
   */ 
  public static void InsertObjects(String hostname, String dbname)
    {
      System.out.println("=========== InsertObjects ==========\n");

      MtDatabase dbcon = new MtDatabase(hostname, dbname);

      // Open the connection to the database and start a transaction
      dbcon.open();
      dbcon.startTransaction();

      try {
	    Connection jdbcon = dbcon.getJDBCConnection();
	    // Create an instance of PreparedStatement
	    String commandText = "INSERT INTO examples.java_examples.jdbc.Person (FirstName, LastName, Age) VALUES (?, ?, ?)";
	    PreparedStatement pstmt = jdbcon.prepareStatement(commandText);
	    pstmt.setEscapeProcessing(false);

	    // Set parameters
	    pstmt.setString(1, "James");
	    pstmt.setString(2, "Watson");
	    pstmt.setInt(3, 75);

	    System.out.println("Query Text #1: " + ((MtPreparedStatement)pstmt).getStmtText());
	    // Execute the INSERT statement
	    int inserted = pstmt.executeUpdate();

	    // Set parameters for the next execution
	    pstmt.setString(1, "Elizabeth");
	    pstmt.setString(2, "Watson");
	    pstmt.setNull(3, java.sql.Types.INTEGER);

	    System.out.println("Query Text #2: " + ((MtPreparedStatement)pstmt).getStmtText());
	    // Execute the INSERT statement with new parameters
	    inserted = pstmt.executeUpdate();

	    // Clean up
	    pstmt.close();

	    // Create an instance of Statement
	    Statement stmt = jdbcon.createStatement();
	    // Set the relationship 'Spouse' between these two Person objects
	    commandText = "SELECT REF(p) FROM examples.java_examples.jdbc.Person p WHERE FirstName = 'James' AND LastName = 'Watson' INTO p1;";
	    stmt.execute(commandText);
	    commandText = "UPDATE examples.java_examples.jdbc.Person SET Spouse = p1 WHERE FirstName = 'Elizabeth' AND LastName = 'Watson';";
	    inserted = stmt.executeUpdate(commandText);

	    // Create a Manager object and two Employee objects who report to the manager
	    commandText = "INSERT INTO examples.java_examples.jdbc.Manager (FirstName, LastName, HireDate, Salary) " +
          "VALUES ('Steve', 'Smith', DATE '2000-09-01', 65000.00) RETURNING INTO theManager;";
	    inserted = stmt.executeUpdate(commandText);

	    commandText = "INSERT INTO examples.java_examples.jdbc.Employee (FirstName, LastName, HireDate, Salary, ReportsTo) " +
          "VALUES ('John', 'Doe', DATE '2001-11-10', 45000.00, theManager);";
	    inserted = stmt.executeUpdate(commandText);

	    commandText = "INSERT INTO examples.java_examples.jdbc.Employee (FirstName, LastName, HireDate, Salary, ReportsTo) " +
          "VALUES ('Dave', 'Edwards', DATE '2002-03-10', 40000.00, theManager);";
	    inserted = stmt.executeUpdate(commandText);

	    commandText = "INSERT INTO examples.java_examples.jdbc.Employee (FirstName, LastName, HireDate, Salary) " +
          "VALUES ('Richad', 'Brown', DATE '2003-03-10', 50000.00);";
	    inserted = stmt.executeUpdate(commandText);

	    // Clean up
	    stmt.close();

      } catch (SQLException e) {
	    System.out.println("SQLException:  " + e.getMessage());      
      }

      // Commit the transaction
      dbcon.commit();

      // Close the database connection
      dbcon.close();

      System.out.println("Done.\n");
    }

  /**
   * Execute an SELECT statement and read the result using DataReader.
   * The SELECT statement specifies its WHERE-clause using Parameters.
   */
  public static void DataReaderValues(String hostname, String dbname)
    {
      System.out.println("=========== DataReaderValues ==========\n");

      MtDatabase dbcon = new MtDatabase(hostname, dbname);
      // Open a connection to the database
      dbcon.open();

      try {
	    Connection jdbcon = dbcon.getJDBCConnection();
	    // Create an instance of PreparedStatement
	    String commandText = "SELECT FirstName, LastName, Spouse.FirstName AS Spouse, Age FROM examples.java_examples.jdbc.Person WHERE LastName = ? LIMIT 10;";
	    PreparedStatement pstmt = jdbcon.prepareStatement(commandText);
	    pstmt.setEscapeProcessing(false);

	    // Set parameters
	    pstmt.setString(1, "Watson");


	    System.out.println("Query Text: " + ((MtPreparedStatement)pstmt).getStmtText());
	    // Execute the SELECT statement and get a ResultSet
	    ResultSet rset = pstmt.executeQuery();
	    
	    System.out.println("Total selected:  " + ((MtResultSet)rset).getTotalNumObjects());
	    System.out.println("Total qualified: " + ((MtResultSet)rset).getTotalNumQualified());
	    System.out.println("");

	    // Print column names
	    ResultSetMetaData rsMetaData = rset.getMetaData();
	    int numberOfColumns = rsMetaData.getColumnCount();
	
	    // get the column names; column indexes start from 1
	    for (int i = 0; i < numberOfColumns; i++) {
          System.out.print(String.format("%16s",rsMetaData.getColumnName(i+1)) + " ");
	    }        
	    System.out.println("");
	    for (int i = 0; i < numberOfColumns; ++i) {
          System.out.print("---------------- ");
	    }
	    System.out.println("");

	    String fname, lname, sfname;
	    Object age;
	    // Read rows one by one
	    while (rset.next())	{
          // Get values for the first and second column
          fname = rset.getString(1);
          lname = rset.getString(2);
          sfname = rset.getString(3);
          age = rset.getInt(4);
          // The third column 'Age' can be null. Check if it is null or not first.
          if (rset.wasNull())
		    age = "NULL";

          // Print the current row
          System.out.println(String.format("%16s",fname) + " " + 
                             String.format("%16s",fname) + " " + 
                             String.format("%16s",sfname) + " " + 
                             age);
	    }

	    // Clean up and close the database connection
	    rset.close();
	    pstmt.close();
      } catch (SQLException e) {
	    System.out.println("SQLException:  " + e.getMessage());      
      }
      if (dbcon.isVersionAccessInProgress())
        dbcon.endVersionAccess();
      else if (dbcon.isTransactionInProgress())
        dbcon.rollback();

      dbcon.close();

      System.out.println("Done.\n");
    }


  /*
   * Execute an SELECT statement and get the selected objects directly
   * as Java objects.
   */
  public static void DataReaderObjects(String hostname, String dbname)
    {
      System.out.println("\n\n=========== DataReaderObjects ==========\n");

      MtDatabase dbcon = new MtDatabase(hostname, dbname);

      // Open a connection to the database
      dbcon.open();

      try {
	    // Create an instance of Statement
	    Statement stmt = dbcon.createStatement();


	    // Set the SELECT statement. Note that we use REF() in the select-list
	    // to get the Java objects directly (rather than values)
	    String commandText = "SELECT REF(p) FROM examples.java_examples.jdbc.Person p WHERE LastName = 'Watson';";

	    System.out.println("Query Text: " + commandText);
	    // Execute the SELECT statement and get a DataReader
	    ResultSet rset = stmt.executeQuery(commandText);

	    System.out.println("Total selected:  " + ((MtResultSet)rset).getTotalNumObjects());
	    System.out.println("Total qualified: " + ((MtResultSet)rset).getTotalNumQualified());
	    System.out.println("");
	    Person p;
	    // Read rows one by one
	    while (rset.next()) {
          // Get the Person object
          p = (Person)rset.getObject(1);

          // Print the current object with spouse's name
          // Note that spouse is directly accessed from the Person object 'p'
          System.out.println("Person: " + 
                             String.format("%16s",p.getFirstName()) + 
                             String.format("%16s",p.getLastName()) + 
                             " Spouse: " + 
                             String.format("%16s", p.getSpouse().getFirstName()));
	    }

	    // Clean up and close the database connection
	    rset.close();
	    stmt.close();
      } catch (SQLException e) {
	    System.out.println("SQLException:  " + e.getMessage());      
      }
      if (dbcon.isVersionAccessInProgress())
	    dbcon.endVersionAccess();
      else if (dbcon.isTransactionInProgress())
	    dbcon.rollback();
      dbcon.close();

      System.out.println("Done.\n");
    }


  /**
   * Execute a Block statement and get the selected objects as C# objects.
   */
  public static void ExecuteBlockStatement(String hostname, String dbname)
    {
      System.out.println("\n\n=========== ExecuteBlockStatement ==========\n");

      MtDatabase dbcon = new MtDatabase(hostname, dbname);

      // Open a connection to the database
      dbcon.open();
      dbcon.startVersionAccess();
      // Set the SQL CURRENT_NAMESPACE to 'examples.java_examples.jdbc' so there is
      // no need to use the full qualified names to acces the schema objects
      dbcon.setSqlCurrentNamespace("examples.java_examples.jdbc");

      CallableStatement stmt = null;

      try {

	    // Set a block statement
	    String commandText =
          "BEGIN\n" +
          "  DECLARE res SELECTION(Employee);\n" +
          "  DECLARE emp_sel SELECTION(Employee);\n" +
          "  DECLARE mgr_sel SELECTION(Manager);\n" +
          "  SELECT REF(p) FROM ONLY Employee p WHERE p.ReportsTo IS NULL INTO emp_sel;\n" +
          "  SELECT REF(p) FROM Manager p WHERE COUNT(p.Team) > 1 INTO mgr_sel;\n" +
          "  SET res = SELECTION(emp_sel UNION mgr_sel);\n" +
          "  RETURN res;\n" +
          "END";

	    Connection jdbcon = dbcon.getJDBCConnection();
	    // Create an instance of CallableStatement
	    stmt = jdbcon.prepareCall(commandText);
        stmt.setEscapeProcessing(false);

	    System.out.println("Query Text:\n" + ((MtCallableStatement)stmt).getStmtText());
	    //  Execute a block statement, and get the returned object selection
	    boolean isRset = stmt.execute();
	    // Get Result Type
        int resultType = ((MtStatement) stmt).getResultType();
	    if ((resultType == MtStatement.METHOD) ||
            (resultType == MtStatement.PROCEDURE)) {
          // CALL statement with a return value
          int returnType = ((MtCallableStatement) stmt).getParamType(0);

          if ( MtType.SELECTION == returnType || 
               MtType.OID == returnType ) {
		    System.out.println("result Type: " + resultType + 
                               " - return Type: " + MtType.toString(returnType) + 
                               " - result Class Type: " + 
                               ((MtCallableStatement)stmt).getStmtInfo(MtStatement.STMT_SELCLASS));

		    Employee[] sel = (Employee[])stmt.getObject(0);

		    System.out.println("result Cnt: " + sel.length);

		    for (Employee e : sel) {
              System.out.println(e.getMtClass().getMtName() + ": " + 
                                 e.getFirstName() + " " + 
                                 e.getLastName() + " - Hiring Date: " + 
                                 String.format("%1$tY-%1$tm-%1$td", e.getHireDate()));
		    }

          }
	    }
      } catch (java.sql.SQLException sqlex) {
	    try { 
          MtStatement mtstmt = (MtStatement)stmt;
          int errorPosition =  Integer.parseInt(mtstmt.getStmtInfo(MtStatement.STMT_ERRPOSITION));
          StringBuffer buf = new StringBuffer();
          for (int i = 1; i < errorPosition; i++) buf.append(" ");
          buf.append("^");
          System.out.println("Error: ");
          System.out.println(buf.toString());
          System.out.println("Failed at line " + mtstmt.getStmtInfo(MtStatement.STMT_ERRLINE) +
                             " - position " + errorPosition);
          System.out.println(sqlex.getMessage());
          String stackTrace = mtstmt.getStmtInfo(MtStatement.STMT_ERRSTACK);
          if (stackTrace != null) {
		    System.out.println("Stack trace:");
		    System.out.println(stackTrace);
          }
	    } catch (Exception e) { 
          e.printStackTrace(); 
	    }
      } finally {
	    // Clean up and close the database connection
	    try { stmt.close(); } catch (Exception e) { e.printStackTrace(); };
        dbcon.endVersionAccess();
	    dbcon.close();
      }

      System.out.println("Done.\n");
    }


  /**
   * Parse SQL statements and get statement types
   */
  public static void ParseSQLQuery(String hostname, String dbname)
    {
      System.out.println("\n\n=========== ParseSQLQuery ==========\n");

      MtDatabase dbcon = new MtDatabase(hostname, dbname);

      // Open a connection to the database
      dbcon.open();
      dbcon.startTransaction();
      // Set the SQL CURRENT_NAMESPACE to 'examples.java_examples.jdbc' so there is
      // no need to use the full qualified names to acces the schema objects
      dbcon.setSqlCurrentNamespace("examples.java_examples.jdbc");

      MtPreparedStatement stmt = null;
      int stmtType;

      try {

	    Connection jdbcon = dbcon.getJDBCConnection();
	    // Set an INSERT statement
	    String commandText = "INSERT INTO Person (FirstName, LastName, Age) VALUES (?, ?, ?);";
	    // Create an instance of PreparedStatement
	    stmt = (MtPreparedStatement)jdbcon.prepareStatement(commandText);
	    stmt.setEscapeProcessing(false);
	
	    // Set parameters
	    stmt.setString(1, "James");
	    stmt.setString(2, "Watson");
	    stmt.setInt(3, 75);

	    System.out.println("Statement #1:");
	    System.out.println(stmt.getStmtText());

	    // Parse the statement and get its type
	    stmtType = stmt.parse();

	    System.out.println("Statement Type: " + stmtTypeToSting(stmtType));

	    commandText = "SELECT LastName FROM Person WHERE LastName = 'Watson';";
	    System.out.println("Statement #2:");
	    System.out.println(commandText);
	    // Parse the statement and get its type
	    stmtType = stmt.parse(commandText);

	    System.out.println("Statement Type: " + stmtTypeToSting(stmtType));

	    // Set an invalid SELECT statement
	    commandText = "SELECT LastName FROM Person p HERE p.LastName = 'Watson';";
	    System.out.println("Statement #2:");
	    System.out.println(commandText);
	    // Parse the statement and get its type
	    stmtType = stmt.parse(commandText);

	    System.out.println("Statement Type: " + stmtTypeToSting(stmtType));

      } catch (java.sql.SQLException sqlex) {
	    try {
          int errorPosition =  Integer.parseInt(stmt.getStmtInfo(MtStatement.STMT_ERRPOSITION));
          StringBuffer buf = new StringBuffer();
          for (int i = 1; i < errorPosition; i++) buf.append(" ");
          buf.append("^");
          System.out.println("Error: ");
          System.out.println(buf.toString());
          System.out.println("Parsing failed at line " + stmt.getStmtInfo(MtStatement.STMT_ERRLINE) +
                             " - position " + errorPosition);
          System.out.println(sqlex.getMessage());
	    } catch (Exception e) { 
          e.printStackTrace(); 
	    }
      } finally {
	    // Clean up and close the database connection
	    try { stmt.close(); } catch (Exception e) { e.printStackTrace(); };
        dbcon.rollback();
	    dbcon.close();
      }

      System.out.println("Done.\n");
    }


  /**
   * Define stored methods using SQL DDL statements
   */
  public static void CreateStoredMethod(String hostname, String dbname)
    {
      System.out.println("\n\n=========== CreateStoredMethod ==========\n");
      MtDatabase dbcon = new MtDatabase(hostname, dbname);

      // Open a connection to the database. No need to start a transaction.
      // execute() will start a transaction in the schema-definition mode automatically.
      dbcon.open();
      // Set the SQL CURRENT_NAMESPACE to 'examples.java_examples.jdbc' so there is
      // no need to use the full qualified names to acces the schema objects
      dbcon.setSqlCurrentNamespace("examples.java_examples.jdbc");

      try {
	    // Create an instance of Statement
	    Statement stmt = dbcon.createStatement();

	    // The first method returns the number of Person objects which have a specified last name
	    String commandText =
          "CREATE STATIC METHOD CountByLName(lname STRING)\n" +
          "RETURNS INTEGER\n" +
          "FOR Person\n" +
          "BEGIN\n" +
          "  DECLARE cnt INTEGER;\n" +
          "  SELECT COUNT(*) INTO cnt FROM Person WHERE LastName = lname;\n" +
          "  RETURN cnt;\n" +
          "END;";
	    System.out.println("creating...\n" + commandText);
	    stmt.execute(commandText);

	    // The second method returns a Person object which has a specified first name and last name
	    commandText =
          "CREATE STATIC METHOD FindByName(lname STRING, fname STRING)\n" +
          "RETURNS Person\n" +
          "FOR Person\n" +
          "BEGIN\n" +
          "  DECLARE obj Person;\n" +
          "  SELECT REF(p) INTO obj FROM Person p WHERE LastName = lname AND FirstName = fname;\n" +
          "  RETURN obj;\n" +
          "END;";
	    System.out.println("\ncreating...\n" + commandText);
	    stmt.execute(commandText);

	    // The thrid method returns a runtime error
	    commandText =
          "CREATE STATIC METHOD GetAnEmployee()\n" +
          "RETURNS Employee\n" +
          "FOR Employee\n" +
          "BEGIN\n" +
          "  DECLARE res SELECTION(Employee);\n" +
          "  SELECT REF(p) FROM Employee p INTO res;\n" +
          "  RETURN res.get(0);\n" +
          "END;";
	    System.out.println("\ncreating...\n" + commandText);
	    stmt.execute(commandText);

	    // clean up
	    stmt.close();
      } catch (SQLException e) {
	    System.out.println("SQLException:  " + e.getMessage());      
      }

      // Commit the transaction and close the connection
      dbcon.commit();
      dbcon.close();

      System.out.println("Done.\n");
    }


  /**
   * Call a stored method, and get the returned integer value
   */
  public static void CallStoredMethod1(String hostname, String dbname)
    {
      System.out.println("\n\n=========== CallStoredMethod1 ==========\n");
      MtDatabase dbcon = new MtDatabase(hostname, dbname);

      // Open a connection to the database.
      dbcon.open();
      dbcon.startVersionAccess();
      // Set the SQL CURRENT_NAMESPACE to 'examples.java_examples.jdbc' so there is
      // no need to use the full qualified names to acces the schema objects
      dbcon.setSqlCurrentNamespace("examples.java_examples.jdbc");

      try {
	    // Specify the stored method. Since it is a static method that we will call,
	    // the name is consisted of class name and method name.
	    String commandText = "CALL Person::CountByLName(?);";

	    Connection jdbcon = dbcon.getJDBCConnection();
	    // Create an instance of CallableStatement
	    CallableStatement stmt = jdbcon.prepareCall(commandText);
        stmt.setEscapeProcessing(false);

	    // Set parameters
	    stmt.setString(1, "Watson");

	    //Execute the stored method
	    stmt.execute();

	    // Get the returned value
	    int count = stmt.getInt(0);

	    // Print it
	    System.out.println(count + " objects found");

	    // clean up 
	    stmt.close();

      } catch (SQLException e) {
	    System.out.println("SQLException:  " + e.getMessage());      
      }

      // close the connection
      dbcon.endVersionAccess();
      dbcon.close();

      System.out.println("Done.\n");
    }


  /**
   * Call a stored method, and get the returned object directly.
   * Note that no Object-Relational mapping is needed.
   */
  public static void CallStoredMethod2(String hostname, String dbname)
    {
      System.out.println("\n\n=========== CallStoredMethod2 ==========\n");

      MtDatabase dbcon = new MtDatabase(hostname, dbname);

      // Open a connection to the database.
      dbcon.open();
      dbcon.startVersionAccess();
      // Set the SQL CURRENT_NAMESPACE to 'examples.java_examples.jdbc' so there is
      // no need to use the full qualified names to acces the schema objects
      dbcon.setSqlCurrentNamespace("examples.java_examples.jdbc");

      try {
	    // Use CALL syntax to call the method
	    String commandText = "CALL Person::FindByName('Watson', 'James');";

	    Connection jdbcon = dbcon.getJDBCConnection();
	    // Create an instance of CallableStatement
	    CallableStatement stmt = jdbcon.prepareCall(commandText);
        stmt.setEscapeProcessing(false);

	    // Execute the stored method, and get the returned object
	    stmt.execute();
	    Person p = (Person)stmt.getObject(0);

	    // Print it
	    System.out.println("Found: " +  p.getLastName() + " " + p.getFirstName());

	    // clean up
	    stmt.close();
      } catch (SQLException e) {
	    System.out.println("SQLException:  " + e.getMessage());      
      }

      // close the connection
      dbcon.endVersionAccess();
      dbcon.close();
 
      System.out.println("Done.\n");
   }



  /**
   * Call a stored method, and get the execution stack trace.
   */
  public static void CallStoredMethod3(String hostname, String dbname)
    {
      System.out.println("\n\n=========== CallStoredMethod3 ==========\n");

      MtDatabase dbcon = new MtDatabase(hostname, dbname);

      // Open a connection to the database.
      dbcon.open();
      dbcon.startVersionAccess();
      // Set the SQL CURRENT_NAMESPACE to 'examples.java_examples.jdbc' so there is
      // no need to use the full qualified names to acces the schema objects
      dbcon.setSqlCurrentNamespace("examples.java_examples.jdbc");

      MtCallableStatement stmt = null;
      try {
	    // Use CALL syntax to call the method
	    String commandText = "CALL Employee::GetAnEmployee();";

	    Connection jdbcon = dbcon.getJDBCConnection();
	    // Create an instance of CallableStatement
	    stmt = (MtCallableStatement)jdbcon.prepareCall(commandText);
        stmt.setEscapeProcessing(false);


	    // Execute the stored method, and get the returned object
	    stmt.execute();
	    Employee e = (Employee)stmt.getObject(0);;

	    // Print it
	    System.out.println("Found: " +  e.getLastName() + " " + e.getFirstName());

      } catch (java.sql.SQLException sqlex) {
	    try { 
          String stackTrace = stmt.getStmtInfo(MtStatement.STMT_ERRSTACK);
          System.out.println("Error: ");
          /* System.out.println(stmt.getStmtText()); */
          System.out.println("");
          System.out.println(sqlex.getMessage());
          System.out.println("Stack trace:");
          System.out.println(stackTrace);
	    } catch (Exception e) { 
          e.printStackTrace(); 
	    }
      } finally {
	    // Clean up and close the database connection
	    try { stmt.close(); } catch (Exception e) { e.printStackTrace(); };
        dbcon.endVersionAccess();
	    dbcon.close();
      }

      System.out.println("Done.\n");
    }

  public static String stmtTypeToSting(int stmtType) {
    String msg = "";

    switch (stmtType) {
	case MtStatement.ALLOCATED:
      msg = "Allocated statement successfully parsed.";
      break;
	case MtStatement.SELECT:
      msg = "Select statement successfully parsed.";
      break;
	case MtStatement.SET_TRANSACTION:
      msg = "Set Transaction statement successfully parsed.";
      break;
	case MtStatement.SET_OPTION:
      msg = "Set Option statement successfully parsed.";
      break;
	case MtStatement.DROP_SELECTION:
      msg = "Drop Selection statement successfully parsed.";
      break;
	case MtStatement.COMMIT:
      msg = "Commit Transaction statement successfully parsed.";
      break;
	case MtStatement.ROLLBACK:
      msg = "Rollback Transaction statement successfully parsed.";
      break;
	case MtStatement.UPDATE:
      msg = "Update statement successfully parsed.";
      break;
	case MtStatement.DELETE:
      msg = "Delete statement successfully parsed.";
      break;
	case MtStatement.INSERT:
      msg = "Insert statement successfully parsed.";
      break;
	case MtStatement.ALTER_ADD:
      msg = "Alter Add statement successfully parsed.";
      break;
	case MtStatement.ALTER_DROP:
      msg = "Alter Drop statement successfully parsed.";
      break;
	case MtStatement.ALTER_ALTER:
      msg = "Alter Alter statement successfully parsed.";
      break;
	case MtStatement.ALTER_RENAME:
      msg = "Alter Rename statement successfully parsed.";
      break;
	case MtStatement.DROP:
      msg = "Drop statement successfully parsed.";
      break;
	case MtStatement.CREATE:
      msg = "Create statement successfully parsed.";
      break;
	case MtStatement.EVENT:
      msg = "Event statement successfully parsed.";
      break;
	case MtStatement.METHOD:
      msg = "Call Method statement successfully parsed.";
      break;
	case MtStatement.PROCEDURE:
      msg = "Block statement successfully parsed.";
      break;
	case MtStatement.COMPILE:
      msg = "Compile Method statement successfully parsed.";
      break;
	case MtStatement.ERROR:
      msg = "One error reported.";
      break;
	default:
      msg = "Unknown statement type (" + stmtType + ") reported.";
    }
    return msg;
  }

}


