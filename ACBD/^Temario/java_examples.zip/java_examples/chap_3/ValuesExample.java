/*
 *  Copyright (c) 1992-2014 Matisse Software Inc. All Rights Reserved.
 *
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 *
 */

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.math.BigDecimal;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import com.matisse.MtDatabase;
import com.matisse.MtPackageObjectFactory;
import com.matisse.MtException;
import com.matisse.reflect.MtType; 

/**
 * This class shows how to update Matisse objects attributes of various types.
 * It also shows how to stream data in/out of an attribute value of type Blob 
 * or Multimedia.
 * Lastly it shows how to catch a specific exception.
 *
 */
public class ValuesExample {

  public static void main(String[] args) {
    if (args.length < 2)
    {
      System.out.println("Need to specify <HOST> <DATABASE>");
      System.exit(-1);
    }

    String hostname = args[0];
    String dbname = args[1];

    // Set attribute values to an object
    setObjectValues(hostname, dbname);

    // Get object attribute values
    getObjectValues(hostname, dbname);

	// Update object attribute values
    updateObjectValues(hostname, dbname);

	// Remove object attribute values
    removeObjectValues(hostname, dbname);

	// Set object attribute value to NULL
    setNullValues(hostname, dbname);

	// Read Write Streaming Values
    readWriteStreamingValues(hostname, dbname);

	// Catch MtException in a Set Value Context
    catchMtException(hostname, dbname);

	// Delete created Objects
	deleteObjects(hostname, dbname);

  }


  /**
   * Set Attribute Values to an object
   */ 
  public static void setObjectValues(String hostname, String dbname)
    {
      System.out.println("=========== SetObjectValues ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chap_3" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chap_3"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the Java class Person, which is not defined in a package 
        // maps to the schema class Person defined in the "examples.java_examples.chap_3" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("","examples.java_examples.chap_3"));

	    db.open();
	    db.startTransaction();

	    Employee e = new Employee(db);

	    // Setting strings
	    e.setComment("FirstName, LastName, Age, HireDate & Salary Set");
	    e.setFirstName("John");
	    e.setLastName("Jones");

	    // Setting numbers
	    e.setAge(42);

	    // Setting Date 
	    e.setHireDate(new GregorianCalendar(2008, Calendar.NOVEMBER, 8));

	    // Setting Numeric
	    e.setSalary(new BigDecimal("7421.25"));

	    db.commit();

	    db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }

    }

  /**
   * Get object attribute values
   */ 
  public static void getObjectValues(String hostname, String dbname)
    {
      System.out.println("=========== GetObjectValues ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chap_3" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chap_3"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the Java class Person, which is not defined in a package 
        // maps to the schema class Person defined in the "examples.java_examples.chap_3" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("","examples.java_examples.chap_3"));

	    db.open();

	    db.startTransaction();

	    // Retrieve the object from the previous transaction
	    Iterator<Employee> iter = Employee.<Employee>instanceIterator(db);
	    Employee e = iter.next();     

	    // Getting
	    System.out.println("\nComment: " + e.getComment());
	    System.out.println("\t" + e.getMtClass().getMtName()+ ": " + 
                           e.getFirstName() + " " +
                           e.getLastName());
	    // suppresses output if no value set
	    if (!e.isAgeNull())
          System.out.println("\t" + e.getAge() + " years old");
	    System.out.println("\tNumber of dependents:  " +
                           e.getDependents());
	    System.out.println("\tSalary:  $" + e.getSalary());
	    System.out.println("\tHiring Date:  " + String.format("%1$tY-%1$tm-%1$td", e.getHireDate()));

	    db.rollback();

	    db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }

    }


  /**
   * Update object attribute values
   */ 
  public static void updateObjectValues(String hostname, String dbname)
    {
      System.out.println("=========== UpdateObjectValues ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chap_3" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chap_3"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the Java class Person, which is not defined in a package 
        // maps to the schema class Person defined in the "examples.java_examples.chap_3" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("","examples.java_examples.chap_3"));

	    db.open();

	    db.startTransaction();

	    // Retrieve the object from the previous transaction
	    Iterator<Employee> iter = Employee.<Employee>instanceIterator(db);
	    Employee e = iter.next();     
    
	    // changing values (getting & setting)
	    e.setDependents(e.getDependents()+2);
	    if (e.getFirstName().equals("John")) {
          e.setSalary(e.getSalary().multiply(new BigDecimal("1.08")));
	    }
	    e.setComment("Dependents & Salary Updated");

	    // Getting again to show changes
	    System.out.println("\nComment: " + e.getComment());
	    System.out.println("\t" + e.getMtClass().getMtName()+ ": " + 
                           e.getFirstName() + " " +
                           e.getLastName());
	    // suppresses output if no value set
	    if (!e.isAgeNull())
          System.out.println("\t" + e.getAge() + " years old");
	    System.out.println("\tNumber of dependents:  " +
                           e.getDependents());
	    System.out.println("\tSalary:  $" + e.getSalary());
    
	    db.commit();

	    db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }

    }

  /**
   * Remove object attribute values
   */ 
  public static void removeObjectValues(String hostname, String dbname)
    {
      System.out.println("=========== RemoveObjectValues ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chap_3" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chap_3"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the Java class Person, which is not defined in a package 
        // maps to the schema class Person defined in the "examples.java_examples.chap_3" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("","examples.java_examples.chap_3"));

	    db.open();

	    db.startTransaction();

	    // Retrieve the object from the previous transaction
	    Iterator<Employee> iter = Employee.<Employee>instanceIterator(db);
	    Employee e = iter.next();     
    
	    // Removing value returns attribute to default
	    e.removeAge();
	    e.removeDependents();
	    e.setComment("Age & Dependents Value Removed");

	    // Getting again to show effect of removing value
	    System.out.println("\nComment: " + e.getComment());
	    System.out.println("\t" + e.getMtClass().getMtName() + ": " + 
                           e.getFirstName() + " " +
                           e.getLastName());
	    if (!e.isAgeNull())
          System.out.println("\t" + e.getAge() + " years old");
	    else
          System.out.println("\tAge: null" +
                             (e.isAgeDefaultValue() ? " (default value)" : ""));

	    System.out.println("\tBirthdate:  " + e.getBirthdate() +
                           (e.isBirthdateDefaultValue() ? " (default value)" : ""));

	    System.out.println("\tNumber of dependents:  " +
                           e.getDependents() + 
                           (e.isDependentsDefaultValue() ? " (default value)" : ""));
    
	    db.commit();

	    db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }

    }

  /**
   * Set object attribute value to NULL
   */ 
  public static void setNullValues(String hostname, String dbname)
    {
      System.out.println("=========== SetNullValues ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chap_3" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chap_3"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the Java class Person, which is not defined in a package 
        // maps to the schema class Person defined in the "examples.java_examples.chap_3" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("","examples.java_examples.chap_3"));

	    db.open();

	    db.startTransaction();

	    // Retrieve the object from the previous transaction
	    Iterator<Employee> iter = Employee.<Employee>instanceIterator(db);
	    Employee e = iter.next();     

	    // Setting NULL
	    System.out.println("Setting Comment to null... ");
	    e.setComment(null);

	    System.out.println("Setting Age to null... ");
	    e.setNull(Employee.getAgeAttribute(db));

	    // Getting again to show effect of setting nulls
	    // output is "null" because getComment value is null
	    System.out.println("\nComment: " + e.getComment());
	    System.out.println("\t" + e.getMtClass().getMtName()+ ": " + 
                           e.getFirstName() + " " +
                           e.getLastName());
	    // suppresses output because value is null
	    if (!e.isAgeNull())
          System.out.println("\t" + e.getAge() + " years old");
	    else
          System.out.println("\tAge: null" +
                             (e.isAgeDefaultValue() ? " (default value)" : ""));
	    System.out.println("\tNumber of dependents:  " +
                           e.getDependents());

	    db.commit();

	    db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }

    }
    

  /**
   * Read Write Streaming Values
   */ 
  public static void readWriteStreamingValues(String hostname, String dbname)
    {
      System.out.println("=========== ReadWriteStreamingValues ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chap_3" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chap_3"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the Java class Person, which is not defined in a package 
        // maps to the schema class Person defined in the "examples.java_examples.chap_3" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("","examples.java_examples.chap_3"));

	    db.open();

	    db.startTransaction();

	    // Retrieve the object from the previous transaction
	    Iterator<Employee> iter = Employee.<Employee>instanceIterator(db);
	    Employee e = iter.next();     

	    System.out.println("Streaming an image in...");
	    // Setting blobs

	    // set to 512 for demo purpose
	    // a few Mega-bytes would be more appropriate 
	    // for real multimedia objects (audio, video, high-resolution photos) 
	    int bufSize = 512;
	    int num, total;
	    byte buffer[] = new byte[bufSize];
	    try {
          InputStream is = new FileInputStream("matisse.gif");
          // reset the stream
          e.setPhotoElements(buffer, MtType.BEGIN_OFFSET, 0, true);
          do {
		    num = is.read(buffer, 0, bufSize);
		    if (num > 0) {
              e.setPhotoElements(buffer, MtType.CURRENT_OFFSET, num,
                                 false);
		    }
          } while (num == bufSize);
          is.close();
	    } catch (IOException ex) {
          ex.printStackTrace();
	    }
	    System.out.println("Image of " + e.getPhotoSize() + " bytes stored.");

	    System.out.println("Streaming an image out...");
	    // Getting blobs (save value of e.Photo as out.gif in the
	    // program directory)
	    total = 0;
	    try {
          OutputStream os = new FileOutputStream("out.gif");
          // reset the stream
          e.getPhotoElements(buffer, MtType.BEGIN_OFFSET, 0);
          do {
		    num = e.getPhotoElements(buffer, MtType.CURRENT_OFFSET,
                                     bufSize);
		    if (num > 0) {
              os.write(buffer, 0, num);
		    }
		    total += num;
          } while (num == bufSize);
          os.close();
	    } catch (IOException ex) {
          ex.printStackTrace();
	    }
	    System.out.println("Image of " + total + " bytes read.");

	    db.commit();

	    db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }

    }

  /**
   * Catch MtException in a Set Value Context
   */ 
  public static void catchMtException(String hostname, String dbname)
    {
      System.out.println("=========== CatchMtException ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chap_3" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chap_3"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the Java class Person, which is not defined in a package 
        // maps to the schema class Person defined in the "examples.java_examples.chap_3" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("","examples.java_examples.chap_3"));

	    db.open();

	    //read-only access
	    db.startVersionAccess();

	    // Retrieve the object from the previous transaction
	    Iterator<Employee> iter = Employee.<Employee>instanceIterator(db);
	    Employee e = iter.next();     

	    try {
          System.out.println("\nAccessing " + e.getMtClass().getMtName()+ " " +
                             e.getFirstName() + " " +
                             e.getLastName() + " in read-only mode.");
          /* Since this transaction is read-only, the following
             will fail, resulting in an error message in the
             program output. */
          System.out.println("Updating Salary... ");
          e.setSalary(new BigDecimal("1e20"));
	    } catch(MtException ex) {
          System.out.print(ex);
          if (ex.getErrorCode() == MtException.NOTRANS)
		    System.out.println(" ... as expected.");
          else
		    System.out.println(" ... but was not expected.");
	    }

	    db.endVersionAccess();

	    db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }

    }

  /**
   * Delete Created Objects
   */ 
  public static void deleteObjects(String hostname, String dbname)
    {
      System.out.println("=========== DeleteObjects ==========\n");

      try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
        // "com.mycomp.myapp" package and the schema class Person defined in the 
        // "examples.java_examples.chap_3" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chap_3"));
        // As an alternative you can use the generated examplesSchemaMap.txt file that
        // defines a direct class mapping between the Java classes and the schema
        // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
        //
        // In this example, the Java class Person, which is not defined in a package 
        // maps to the schema class Person defined in the "examples.java_examples.chap_3" namespace
        //
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("","examples.java_examples.chap_3"));

	    db.open();

	    db.startTransaction();

	    // List all Employee objects
	    System.out.println("\n" + Employee.getInstanceNumber(db) +
                           " Employee(s) in the database.");
	    System.out.println("Deleting all Employees...");
	    // Retrieve the object from the previous transaction
	    Iterator<Employee> iter = Employee.<Employee>instanceIterator(db);
	    while (iter.hasNext()) {
          Employee e = iter.next();
          // Remove created objects
          // NOTE: does not remove the object sub-parts
          //e.remove();
		    
          // To remove object sub-parts Overrides MtObject.deepRemove() 
          // see Person.deepRemove()
          e.deepRemove();
	    }

	    db.commit();

	    db.close();

	    System.out.println("\nDone.");
      } catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
      }

    }

}
