/*
 *  Copyright (c) 1992-2014 Matisse Software Inc. All Rights Reserved.
 *
 *  This file (in both binary and source code form) is subject to the
 *  Supplemental License Terms governing use, modification and redistribution
 *  of Sample Code accompanying the Matisse(R) software.
 *
 */

import java.util.GregorianCalendar;
import java.math.BigDecimal;
import java.util.Iterator;

import com.matisse.MtDatabase;
import com.matisse.MtPackageObjectFactory;
import com.matisse.MtException;
import com.matisse.MtObjectIterator;


/**
 * This class shows how to create/list/delete objects with Matisse.
 *
 */
public class ObjectsExample {

    public static void main(String[] args) {
	if (args.length < 2) {
	    System.out.println("Need to specify <HOST> <DATABASE>");
	    System.exit(-1);
	}

	String hostname = args[0];
	String dbname = args[1];

	// Create a few Person objects
	createObjects(hostname, dbname);

	// List the created objects
	listObjects(hostname, dbname);

	// List objects from Class (excluding subclasses)
	listOwnInstances(hostname, dbname);

	// Load a large number od Employee objects
	loadObjects(hostname, dbname);

	// Delete some of the created objects
	deleteObjects(hostname, dbname);

	// Delete all the remaining objects
	deleteAllObjects(hostname, dbname);

	// Check if the objects are all gone
	listObjects(hostname, dbname);

    }

    /**
     * Create a few Person objects
     */ 
    public static void createObjects(String hostname, String dbname)
    {
	System.out.println("=========== CreateObjects ==========\n");

	try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
	    // "com.mycomp.myapp" package and the schema class Person defined in the 
	    // "examples.java_examples.chap_3" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chap_3"));
	    // As an alternative you can use the generated examplesSchemaMap.txt file that
	    // defines a direct class mapping between the Java classes and the schema
	    // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
	    //
	    // In this example, the Java class Person, which is not defined in a package 
	    // maps to the schema class Person defined in the "examples.java_examples.chap_3" namespace
	    //
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("","examples.java_examples.chap_3"));

	    db.open();
	    db.startTransaction();
        
	    // Create a new Person object (instance of class Person)
	    Person p = new Person(db);
	    p.setFirstName("John");
	    p.setLastName("Smith");
	    p.setAge(42);
	    PostalAddress a = new PostalAddress(db);
	    a.setCity("Portland");
	    a.setPostalCode("97201");
	    p.setAddress(a);
	    System.out.println("Person John Smith created.");

	    // Create a new Employee object
	    Employee e = new Employee(db);
	    e.setFirstName("Jane");
	    e.setLastName("Jones");
	    // Age is nullable we can leave it unset
	    e.setHireDate(new GregorianCalendar());
	    e.setSalary(new BigDecimal(85000.00));
	    System.out.println("Employee Jane Jones created.");

	    db.commit();
	    db.close();
	    System.out.println("\nDone.");
	} catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
	}
    }


    /**
     * List objects
     */ 
    public static void listObjects(String hostname, String dbname)
    {
	System.out.println("=========== ListObjects ==========\n");

	try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
	    // "com.mycomp.myapp" package and the schema class Person defined in the 
	    // "examples.java_examples.chap_3" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chap_3"));
	    // As an alternative you can use the generated examplesSchemaMap.txt file that
	    // defines a direct class mapping between the Java classes and the schema
	    // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
	    //
	    // In this example, the Java class Person, which is not defined in a package 
	    // maps to the schema class Person defined in the "examples.java_examples.chap_3" namespace
	    //
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("","examples.java_examples.chap_3"));

	    db.open();
	    db.startVersionAccess();

	    // List all Person objects
	    System.out.println("\n" + Person.getInstanceNumber(db) +
			       " Person(s) in the database.");
	    System.out.println("\n" + PostalAddress.getInstanceNumber(db) +
			       " Address(s) in the database.");
	    Iterator<Person> iter = Person.instanceIterator(db);
	    while (iter.hasNext()) {
		Person x = iter.next();     
		System.out.println("\t" + x.getFirstName() + " " + x.getLastName()  + 
				   " from " + (x.getAddress() != null ? x.getAddress().getCity() : "???") + 
				   " is a " + x.getMtClass().getMtName());
	    }

	    // Method specific to Matisse
	    // Open the iterator and position the cursor to the the first person
	    MtObjectIterator<Person> mtiter = Person.instanceIterator(db);
	    // do nothing
	    int skippedCnt = mtiter.skip(0);
	    System.out.println("\n" + skippedCnt +
			       " Person skipped in the iterator.");
	    // Skip the first person and position the cursor to the second person
	    skippedCnt = mtiter.skip(1);
	    System.out.println("\n" + skippedCnt +
			       " more Person skipped in the iterator.");
	    // Skip the second person and position the cursor to the 12th person if it exists
	    skippedCnt = mtiter.skip(10);
	    System.out.println("\n" + skippedCnt +
			       " more Person(s) skipped in the iterator.");
	    // Skip while already at the end
	    skippedCnt = mtiter.skip(10);
	    System.out.println("\n" + skippedCnt +
			       " more Person(s) skipped in the iterator.");
	    mtiter.close();

	    db.endVersionAccess();
	    db.close();

	    System.out.println("\nDone.");
	} catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
	}
    }

    /**
     * List objects from Class (excluding subclasses)
     */ 
    public static void listOwnInstances(String hostname, String dbname)
    {
	System.out.println("=========== listOwnInstances ==========\n");

	try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
	    // "com.mycomp.myapp" package and the schema class Person defined in the 
	    // "examples.java_examples.chap_3" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chap_3"));
	    // As an alternative you can use the generated examplesSchemaMap.txt file that
	    // defines a direct class mapping between the Java classes and the schema
	    // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
	    //
	    // In this example, the Java class Person, which is not defined in a package 
	    // maps to the schema class Person defined in the "examples.java_examples.chap_3" namespace
	    //
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("","examples.java_examples.chap_3"));

	    db.open();
	    db.startVersionAccess();

	    // List all Person objects (excluding Employee sub-class)
	    System.out.println("\n" + Person.getOwnInstanceNumber(db) +
			       " Person(s) (excluding subclasses) in the database.");

	    MtObjectIterator<Person> iter = Person.<Person>ownInstanceIterator(db);

	    while (iter.hasNext()) {
		Person x = iter.next();     
		System.out.println("\t" + x.getFirstName() + " " + x.getLastName()  + 
				   " from " + (x.getAddress() != null ? x.getAddress().getCity() : "???") + 
				   " is a " + x.getMtClass().getMtName());
	    }
	    iter.close();

	    db.endVersionAccess();
	    db.close();

	    System.out.println("\nDone.");
	} catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
	}
    }

    /**
     * Delete some objects
     */ 
    public static void deleteObjects(String hostname, String dbname)
    {
	System.out.println("=========== DeleteObjects ==========\n");

	try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
	    // "com.mycomp.myapp" package and the schema class Person defined in the 
	    // "examples.java_examples.chap_3" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chap_3"));
	    // As an alternative you can use the generated examplesSchemaMap.txt file that
	    // defines a direct class mapping between the Java classes and the schema
	    // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
	    //
	    // In this example, the Java class Person, which is not defined in a package 
	    // maps to the schema class Person defined in the "examples.java_examples.chap_3" namespace
	    //
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("","examples.java_examples.chap_3"));

	    db.open();
	    db.startTransaction();
        
	    // List all Person objects
	    System.out.println("\n" + Person.getInstanceNumber(db) +
			       " Person(s) in the database.");

	    MtObjectIterator<Person> iter = Person.<Person>instanceIterator(db);

	    System.out.println("Deleting a few Persons");
	    while (iter.hasNext()) {
		Person[] persons = iter.next(25); 
		System.out.println("Deleting " + persons.length + " Person(s)...");
		for (int i=0; i < persons.length; i++) {
		    // Remove created objects
		    // NOTE: does not remove the object sub-parts
		    //persons[i].remove();

		    // To remove object sub-parts Overrides MtObject.deepRemove() 
		    // see Person.deepRemove()
		    persons[i].deepRemove();
		}
		// delete only the first batch of objects
		break;
	    }
	    iter.close();

	    db.commit();
	    db.close();

	    System.out.println("\nDone.");
	} catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
	}
    }

    /**
     * Delete all the objects
     */ 
    public static void deleteAllObjects(String hostname, String dbname)
    {
	System.out.println("=========== deleteAllObjects ==========\n");

	try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
	    // "com.mycomp.myapp" package and the schema class Person defined in the 
	    // "examples.java_examples.chap_3" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chap_3"));
	    // As an alternative you can use the generated examplesSchemaMap.txt file that
	    // defines a direct class mapping between the Java classes and the schema
	    // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
	    //
	    // In this example, the Java class Person, which is not defined in a package 
	    // maps to the schema class Person defined in the "examples.java_examples.chap_3" namespace
	    //
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("","examples.java_examples.chap_3"));

	    db.open();
	    db.startTransaction();
        
	    // List all Person objects
	    System.out.println("\n" + Person.getInstanceNumber(db) +
			       " Person(s) in the database.");

	    System.out.println("Deleting all remaining Persons...");
	    // Delete all the instances of the Person Class
	    Person.getClass(db).removeAllInstances();	    

	    db.commit();
	    db.close();

	    System.out.println("\nDone.");
	} catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
	}
    }


    static int DEFAULT_ALLOCATOR_CNT = 50;
    static int SAMPLE_OBJECT_CNT = 100;
    static int OBJECT_PER_TRAN_CNT = 20;

    /**
     * Load a large number of objects
     */ 
    public static void loadObjects(String hostname, String dbname)
    {
	System.out.println("=========== LoadObjects ==========\n");
	java.util.Random sampleSeq = new java.util.Random(179351359);	    

	try {
	    // The third argument is given so that the connection object can find
	    // the mapping between the Java class Person, which is defined in the 
	    // "com.mycomp.myapp" package and the schema class Person defined in the 
	    // "examples.java_examples.chap_3" namespace.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("com.mycomp.myapp","examples.java_examples.chap_3"));
	    // As an alternative you can use the generated examplesSchemaMap.txt file that
	    // defines a direct class mapping between the Java classes and the schema
	    // classes.
	    // MtDatabase db = new MtDatabase(hostname, dbname, new MtExplicitObjectFactory("examplesSchemaMap.txt"));
	    //
	    // In this example, the Java class Person, which is not defined in a package 
	    // maps to the schema class Person defined in the "examples.java_examples.chap_3" namespace
	    //
	    MtDatabase db = new MtDatabase(hostname, dbname, new MtPackageObjectFactory("","examples.java_examples.chap_3"));

	    db.open();

	    db.startTransaction();

	    // Optimize the objects loading
	    // Preallocate OIDs so objects can be created in the client workspace 
	    // without requesting any further information from the server
	    db.preallocate(DEFAULT_ALLOCATOR_CNT);
        
	    for (int i = 1; i <= 100; i++) {
		// Create a new Employee object
		Employee e = new Employee(db);
		String fname = fNameSample[sampleSeq.nextInt(MAX_SAMPLES)];
		String lname = lNameSample[sampleSeq.nextInt(MAX_SAMPLES)];
		e.setFirstName(fname);
		e.setLastName(lname);
		e.setHireDate(new GregorianCalendar());
		e.setSalary(new BigDecimal(salarySample[sampleSeq.nextInt(MAX_SAMPLES)]));
		PostalAddress a = new PostalAddress(db);
		int addrIdx = sampleSeq.nextInt(MAX_SAMPLES);
		a.setCity(addressSample[addrIdx][0]);
		a.setPostalCode(addressSample[addrIdx][1]);
		e.setAddress(a);
		System.out.println("Employee "+i+ " " + fname + " " + lname + "  created.");
		if (i % OBJECT_PER_TRAN_CNT == 0) {
		    db.commit();
		    db.startTransaction();
		}
		// check the remaining number of preallocated objects.
		if (db.numPreallocated() < 2) {
		    db.preallocate(DEFAULT_ALLOCATOR_CNT);
		}
	    }

	    if (db.isTransactionInProgress())
		db.commit();

	    db.close();

	    System.out.println("\nDone.");
	} catch (MtException mte) {
	    System.out.println("MtException : " + mte.getMessage());
	    mte.printStackTrace();
	}
    }

    // Data samples
    static int MAX_SAMPLES = 7;

    static  String[] fNameSample = {
	"Jonathan",
	"Paul",
	"Pamela",
	"Victoria",
	"David",
	"Ame",
	"Teresa"
    };

    static  String[] lNameSample = {
	"Ronaldson",
	"Douglasson",
	"Lorison",
	"Staceyson",
	"Nicoleson",
	"Sharleneson",
	"Jeremyson"
    };

    static int[] salarySample = {
	40000,
	30000,
	85000,
	35000,
	55000,
	65000,
	70000
    };

    static String[][] addressSample = {
	{"Portland","97201"} ,
	{"Stuttgart","70563"} ,
	{"Bergamo","24100"} ,
	{"Reims","51100"} ,
	{"Leipzig","04179"} ,
	{"Rio de Janeiro","02389-890"} ,
	{"Sao Paulo","05432-043"} 
    };


}
